/*
 * Live updates.
 *
 * The server pushes small messages over a WebSocket (STOMP over SockJS) whenever
 * something happens: a job is posted or reviewed, someone applies, a candidate
 * moves to a new stage. This script shows the newest message on the dashboard.
 *
 * It does nothing on pages that have no #event element or no SockJS/Stomp
 * libraries, so it is safe to include anywhere.
 */
(function () {
  'use strict';

  var box = document.getElementById('event');
  if (!box || typeof SockJS === 'undefined' || typeof Stomp === 'undefined') {
    return;
  }

  // The dashboard bar is <p id="event"><i></i><span>text</span></p>; plain pages use the element itself.
  var textTarget = box.querySelector('span') || box;
  var RETRY_MS = 5000;

  function show(update) {
    if (update && update.message) {
      textTarget.textContent = 'Just now: ' + update.message;
      if (box.animate) {
        box.animate([{ opacity: 0.3 }, { opacity: 1 }], { duration: 450 });
      }
    }
  }

  function connect() {
    var client = Stomp.over(new SockJS('/live'));
    client.debug = null; // keep the browser console quiet

    client.connect({}, function () {
      client.subscribe('/topic/updates', function (frame) {
        try {
          show(JSON.parse(frame.body));
        } catch (e) {
          // Ignore a malformed message rather than breaking the page.
        }
      });
    }, function () {
      // Connection lost or refused: try again in a few seconds.
      setTimeout(connect, RETRY_MS);
    });
  }

  connect();
})();
