INSERT IGNORE INTO users (id,name,email,role,headline,company_name) VALUES
(1,'Aarav Sharma','aarav@demo.hiremeout.local','SEEKER','Java developer who likes clean, useful products',NULL),
(2,'Maya Kapoor','maya@demo.hiremeout.local','EMPLOYER',NULL,'Studio North'),
(3,'Riya Sen','riya@demo.hiremeout.local','ADMIN',NULL,NULL);
INSERT IGNORE INTO jobs (id,employer_id,title,company,location,job_type,description,status) VALUES
(1,2,'Junior Java Developer','Studio North','Bengaluru, Hybrid','Full-time','Build Spring Boot features with a supportive product team.','APPROVED'),
(2,2,'Product Design Intern','Studio North','Remote, India','Internship','Help turn research into friendly user experiences.','PENDING');
INSERT IGNORE INTO applications (id,job_id,seeker_id,cover_note,resume_url,status) VALUES
(1,1,1,'I enjoy building practical Java applications and would love to contribute.','resume-aarav.pdf','REVIEWING');
