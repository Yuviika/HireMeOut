package com.hiremeout.service;

import com.hiremeout.domain.Application;
import com.hiremeout.domain.Job;
import com.hiremeout.domain.Message;
import com.hiremeout.domain.exception.ForbiddenException;
import com.hiremeout.domain.exception.NotFoundException;
import com.hiremeout.domain.exception.ValidationException;
import com.hiremeout.repository.ApplicationRepository;
import com.hiremeout.repository.JobRepository;
import com.hiremeout.repository.MessageRepository;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 * Business rules for the small message thread attached to an application. Only
 * the seeker who applied or the employer who owns the job may read or send
 * messages on that application.
 */
@Service
public class MessageService {

    private static final int BODY_MAX = 2000;

    private final MessageRepository messageRepository;
    private final ApplicationRepository applicationRepository;
    private final JobRepository jobRepository;

    public MessageService(MessageRepository messageRepository, ApplicationRepository applicationRepository, JobRepository jobRepository) {
        this.messageRepository = messageRepository;
        this.applicationRepository = applicationRepository;
        this.jobRepository = jobRepository;
    }

    /** Sends a message on an application's thread, after checking the sender is allowed to see it. */
    public Message send(Long senderId, Long applicationId, String body) {
        if (body == null || body.isBlank()) {
            throw new ValidationException("Message cannot be empty.");
        }
        if (body.trim().length() > BODY_MAX) {
            throw new ValidationException("Message must be " + BODY_MAX + " characters or fewer.");
        }
        requireParticipant(senderId, applicationId);

        Long newId = messageRepository.create(applicationId, senderId, body.trim());
        return messageRepository.findByApplication(applicationId).stream()
                .filter(message -> message.id().equals(newId))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Message could not be loaded after saving."));
    }

    /** Lists every message on an application's thread, after checking the requester is allowed to see it. */
    public List<Message> list(Long applicationId, Long requesterId) {
        requireParticipant(requesterId, applicationId);
        return messageRepository.findByApplication(applicationId);
    }

    private void requireParticipant(Long userId, Long applicationId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new NotFoundException("Application not found."));
        Job job = jobRepository.findById(application.jobId())
                .orElseThrow(() -> new NotFoundException("Job not found for this application."));

        boolean isSeeker = application.seekerId().equals(userId);
        boolean isEmployer = job.employerId().equals(userId);
        if (!isSeeker && !isEmployer) {
            throw new ForbiddenException("You are not part of this conversation.");
        }
    }
}
