package com.hiremeout.service;

import com.hiremeout.domain.ApplicationView;
import com.hiremeout.domain.DashboardSnapshot;
import com.hiremeout.domain.Job;
import com.hiremeout.domain.PortalUser;
import com.hiremeout.domain.exception.NotFoundException;
import com.hiremeout.domain.exception.ValidationException;
import com.hiremeout.repository.ApplicationRepository;
import com.hiremeout.repository.JobRepository;
import com.hiremeout.repository.UserRepository;
import org.springframework.stereotype.Service;

/**
 * Builds the DashboardSnapshot each role sees. Seekers only ever see their own
 * applications, and employers only ever see applications to jobs they posted,
 * so this class is the one place that decides what each role is allowed to view.
 */
@Service
public class DashboardService {

    private final UserRepository userRepository;
    private final JobRepository jobRepository;
    private final ApplicationRepository applicationRepository;

    public DashboardService(UserRepository userRepository, JobRepository jobRepository, ApplicationRepository applicationRepository) {
        this.userRepository = userRepository;
        this.jobRepository = jobRepository;
        this.applicationRepository = applicationRepository;
    }

    /** The seeker's dashboard: every application they have sent, newest first. */
    public DashboardSnapshot<ApplicationView> seekerDashboard(Long userId) {
        PortalUser owner = requireUser(userId);
        var applications = applicationRepository.findViewsBySeeker(userId);
        return DashboardSnapshot.of(owner, applications, "You have " + applications.size() + " application(s).");
    }

    /** The employer's dashboard: every application sent to any job they posted. */
    public DashboardSnapshot<ApplicationView> employerDashboard(Long userId) {
        PortalUser owner = requireUser(userId);
        var applications = applicationRepository.findViewsByEmployer(userId);
        return DashboardSnapshot.of(owner, applications, "You have " + applications.size() + " application(s) to review.");
    }

    /** The admin's dashboard: every job in the system, regardless of status. */
    public DashboardSnapshot<Job> adminDashboard(Long userId) {
        PortalUser owner = requireUser(userId);
        var jobs = jobRepository.findAll();
        long pending = jobs.stream().filter(job -> job.status() == com.hiremeout.domain.JobStatus.PENDING).count();
        return DashboardSnapshot.of(owner, jobs, pending + " job(s) waiting for review.");
    }

    private PortalUser requireUser(Long userId) {
        if (userId == null) {
            throw new ValidationException("A signed-in user is required.");
        }
        return userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException("User not found."));
    }
}
