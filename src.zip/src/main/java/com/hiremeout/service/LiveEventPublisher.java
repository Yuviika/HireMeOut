package com.hiremeout.service;

import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

/**
 * Sends small live-update messages to every browser connected over WebSocket.
 * Other services call publish(...) after something worth announcing happens,
 * such as a new job going live or a candidate moving to a new stage.
 */
@Component
public class LiveEventPublisher {

    private static final String DESTINATION = "/topic/updates";

    private final SimpMessagingTemplate messagingTemplate;

    public LiveEventPublisher(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    /**
     * Publishes one live event.
     *
     * @param type    a short machine-readable kind, e.g. "JOB_POSTED", "APPLICATION_STATUS_CHANGED"
     * @param message a short human-readable line to show on the dashboard
     */
    public void publish(String type, String message) {
        messagingTemplate.convertAndSend(DESTINATION, new LiveEvent(type, message));
    }

    /** The small payload sent over the WebSocket topic. */
    public record LiveEvent(String type, String message) {
    }
}
