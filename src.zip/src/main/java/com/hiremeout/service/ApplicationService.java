package com.hiremeout.service;

import com.hiremeout.domain.Application;
import com.hiremeout.domain.ApplicationStatus;
import com.hiremeout.domain.Job;
import com.hiremeout.domain.exception.ConflictException;
import com.hiremeout.domain.exception.ForbiddenException;
import com.hiremeout.domain.exception.NotFoundException;
import com.hiremeout.domain.exception.ValidationException;
import com.hiremeout.repository.ApplicationRepository;
import com.hiremeout.repository.JobRepository;
import org.springframework.stereotype.Service;

/**
 * Business rules for applying to jobs and moving an application through its
 * stages. Controllers should call this class instead of ApplicationRepository
 * directly, so the duplicate-application check and stage rules are never skipped.
 */
@Service
public class ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final JobRepository jobRepository;
    private final LiveEventPublisher liveEventPublisher;

    public ApplicationService(ApplicationRepository applicationRepository, JobRepository jobRepository, LiveEventPublisher liveEventPublisher) {
        this.applicationRepository = applicationRepository;
        this.jobRepository = jobRepository;
        this.liveEventPublisher = liveEventPublisher;
    }

    /**
     * Applies a seeker to a job. The job must exist and be APPROVED, and the
     * seeker must not have already applied to it. Nothing is published if the
     * application fails, so a duplicate attempt never shows a false live event.
     */
    public Application apply(Long seekerId, Long jobId, String coverNote, String resumeUrl) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new NotFoundException("Job not found."));
        if (job.status() != com.hiremeout.domain.JobStatus.APPROVED) {
            throw new ValidationException("This job is not open for applications.");
        }
        if (applicationRepository.existsByJobAndSeeker(jobId, seekerId)) {
            throw new ConflictException("You have already applied to this job.");
        }

        Long newId = applicationRepository.create(jobId, seekerId, coverNote, resumeUrl);
        Application application = applicationRepository.findById(newId)
                .orElseThrow(() -> new NotFoundException("Application could not be loaded after saving."));

        liveEventPublisher.publish("APPLICATION_RECEIVED", "A candidate applied to " + job.title() + ".");
        return application;
    }

    /**
     * Lets an employer move a candidate to the next stage. Only the employer who
     * owns the job may do this, and only moves that ApplicationStatus.canMoveTo
     * allows are accepted, so a candidate cannot be skipped forward illegally.
     */
    public Application changeStatus(Long employerId, Long applicationId, ApplicationStatus next) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new NotFoundException("Application not found."));
        Job job = jobRepository.findById(application.jobId())
                .orElseThrow(() -> new NotFoundException("Job not found for this application."));

        if (!job.employerId().equals(employerId)) {
            throw new ForbiddenException("You can only manage applications for your own jobs.");
        }
        if (!application.status().canMoveTo(next)) {
            throw new ValidationException("Cannot move from " + application.status().label() + " to " + next.label() + ".");
        }

        applicationRepository.updateStatus(applicationId, next);
        Application updated = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new NotFoundException("Application not found after update."));

        liveEventPublisher.publish("APPLICATION_STATUS_CHANGED", job.title() + " application moved to " + next.label() + ".");
        return updated;
    }
}
