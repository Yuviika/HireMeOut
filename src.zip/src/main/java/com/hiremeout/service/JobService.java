package com.hiremeout.service;

import com.hiremeout.domain.Job;
import com.hiremeout.domain.JobStatus;
import com.hiremeout.domain.PortalUser;
import com.hiremeout.domain.Employer;
import com.hiremeout.domain.exception.ConflictException;
import com.hiremeout.domain.exception.NotFoundException;
import com.hiremeout.domain.exception.ValidationException;
import com.hiremeout.repository.JobRepository;
import com.hiremeout.repository.UserRepository;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 * Business rules for posting and reviewing jobs. Controllers should call this
 * class instead of JobRepository directly, so validation and live events always
 * happen the same way no matter which controller triggers them.
 */
@Service
public class JobService {

    private static final int TITLE_MAX = 140;
    private static final int COMPANY_MAX = 120;
    private static final int LOCATION_MAX = 120;
    private static final int JOB_TYPE_MAX = 40;

    private final JobRepository jobRepository;
    private final UserRepository userRepository;
    private final LiveEventPublisher liveEventPublisher;

    public JobService(JobRepository jobRepository, UserRepository userRepository, LiveEventPublisher liveEventPublisher) {
        this.jobRepository = jobRepository;
        this.userRepository = userRepository;
        this.liveEventPublisher = liveEventPublisher;
    }

    /** Jobs visible on the public job board, optionally filtered by a search term. */
    public List<Job> listApproved(String search) {
        return jobRepository.findApproved(search);
    }

    /** Every job one employer has posted (any status), newest first. */
    public List<Job> listByEmployer(Long employerId) {
        return jobRepository.findByEmployer(employerId);
    }

    /**
     * Posts a new job for an employer. The company name always comes from the
     * employer's own account, never from the form, so nobody can post a job under
     * a different company's name. New jobs start as PENDING until an admin reviews them.
     */
    public Job postJob(Long employerId, String title, String location, String jobType, String description) {
        require(title, "Job title", TITLE_MAX);
        require(location, "Location", LOCATION_MAX);
        require(jobType, "Job type", JOB_TYPE_MAX);
        if (description == null || description.isBlank()) {
            throw new ValidationException("Please describe the role.");
        }

        PortalUser employer = userRepository.findById(employerId)
                .orElseThrow(() -> new NotFoundException("Employer account not found."));
        if (!(employer instanceof Employer employerAccount)) {
            throw new ValidationException("Only employer accounts can post jobs.");
        }
        String company = employerAccount.company();
        if (company == null || company.isBlank()) {
            throw new ValidationException("Add a company name to your account before posting a job.");
        }

        Long newId = jobRepository.create(employerId, title.trim(), company, location.trim(), jobType.trim(), description.trim());
        Job job = jobRepository.findById(newId)
                .orElseThrow(() -> new NotFoundException("Job could not be loaded after saving."));

        liveEventPublisher.publish("JOB_POSTED", "New job posted: " + job.title() + " at " + job.company());
        return job;
    }

    /**
     * Lets an admin approve or reject a job. Only a job that is still PENDING may
     * be reviewed, so a job cannot be approved twice or reviewed after rejection.
     */
    public Job review(Long adminId, Long jobId, JobStatus decision) {
        if (!decision.isDecision()) {
            throw new ValidationException("A review must be either APPROVED or REJECTED.");
        }
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new NotFoundException("Job not found."));
        if (job.status() != JobStatus.PENDING) {
            throw new ConflictException("This job has already been reviewed.");
        }

        jobRepository.updateStatus(jobId, decision);
        Job updated = jobRepository.findById(jobId)
                .orElseThrow(() -> new NotFoundException("Job not found after review."));

        liveEventPublisher.publish("JOB_REVIEWED", "\"" + updated.title() + "\" was " + decision.name().toLowerCase() + ".");
        return updated;
    }

    private void require(String value, String fieldName, int maxLength) {
        if (value == null || value.isBlank()) {
            throw new ValidationException(fieldName + " is required.");
        }
        if (value.trim().length() > maxLength) {
            throw new ValidationException(fieldName + " must be " + maxLength + " characters or fewer.");
        }
    }
}
