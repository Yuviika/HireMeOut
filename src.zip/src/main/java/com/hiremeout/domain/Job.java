package com.hiremeout.domain;

import java.time.LocalDateTime;

/** One job posting, mapped from a row of the jobs table. */
public record Job(
        Long id,
        Long employerId,
        String title,
        String company,
        String location,
        String jobType,
        String description,
        JobStatus status,
        LocalDateTime createdAt) {
}
