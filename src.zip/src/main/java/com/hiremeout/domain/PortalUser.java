package com.hiremeout.domain;

/**
 * Base type shared by every portal role. It holds what all users have in common
 * (id, name, email, role) and leaves the role-specific text to the subclasses.
 */
public abstract class PortalUser implements DashboardProvider {

    private final Long id;
    private final String name;
    private final String email;
    private final Role role;

    protected PortalUser(Long id, String name, String email, Role role) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.role = role;
    }

    public Long id() {
        return id;
    }

    public String name() {
        return name;
    }

    public String email() {
        return email;
    }

    @Override
    public Role role() {
        return role;
    }

    /**
     * Builds the right subclass for a database row. Repositories call this so the
     * rest of the app never has to check the role column itself.
     *
     * @param headline    only used for seekers, may be null
     * @param companyName only used for employers, may be null
     */
    public static PortalUser fromRow(
            Long id, String name, String email, Role role, String headline, String companyName) {
        if (role == null) {
            throw new IllegalArgumentException("A user must have a role.");
        }
        return switch (role) {
            case SEEKER -> new Seeker(id, name, email, headline);
            case EMPLOYER -> new Employer(id, name, email, companyName);
            case ADMIN -> new Admin(id, name, email);
        };
    }
}
