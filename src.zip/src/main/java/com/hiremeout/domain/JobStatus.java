package com.hiremeout.domain;

import com.hiremeout.domain.exception.ValidationException;

/**
 * Moderation state of a job posting. Names must match the MySQL ENUM in schema.sql.
 */
public enum JobStatus {

    PENDING("Waiting for approval"),
    APPROVED("Live on the job board"),
    REJECTED("Rejected by an admin");

    private final String label;

    JobStatus(String label) {
        this.label = label;
    }

    /** Friendly text to show in the UI. */
    public String label() {
        return label;
    }

    /** True for the two outcomes an admin may choose (approve or reject). */
    public boolean isDecision() {
        return this == APPROVED || this == REJECTED;
    }

    /** Converts text from a form into a status, or throws a friendly ValidationException. */
    public static JobStatus fromString(String text) {
        if (text == null || text.isBlank()) {
            throw new ValidationException("Please choose a job status.");
        }
        try {
            return valueOf(text.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ValidationException("Unknown job status: " + text.trim());
        }
    }
}
