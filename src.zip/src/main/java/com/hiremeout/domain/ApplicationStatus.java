package com.hiremeout.domain;

import com.hiremeout.domain.exception.ValidationException;
import java.util.Arrays;
import java.util.List;

/**
 * Where a job application is in the hiring process.
 *
 * The constant names must match the MySQL ENUM in schema.sql. Each constant
 * overrides label() and canMoveTo(), which is polymorphism: the same method call
 * behaves differently depending on which status it is called on.
 */
public enum ApplicationStatus {

    APPLIED {
        @Override
        public String label() {
            return "Application sent";
        }

        @Override
        public boolean canMoveTo(ApplicationStatus next) {
            return next == REVIEWING || next == REJECTED;
        }
    },

    REVIEWING {
        @Override
        public String label() {
            return "Under review";
        }

        @Override
        public boolean canMoveTo(ApplicationStatus next) {
            return next == INTERVIEW || next == REJECTED;
        }
    },

    INTERVIEW {
        @Override
        public String label() {
            return "Interview stage";
        }

        @Override
        public boolean canMoveTo(ApplicationStatus next) {
            return next == OFFER || next == REJECTED;
        }
    },

    OFFER {
        @Override
        public String label() {
            return "Offer made";
        }

        @Override
        public boolean canMoveTo(ApplicationStatus next) {
            return false;
        }
    },

    REJECTED {
        @Override
        public String label() {
            return "Not moving forward";
        }

        @Override
        public boolean canMoveTo(ApplicationStatus next) {
            return false;
        }
    };

    /** Friendly text to show in the UI. */
    public abstract String label();

    /** True if an application in this status may be moved to {@code next}. */
    public abstract boolean canMoveTo(ApplicationStatus next);

    /** True if no further change is possible. */
    public boolean isTerminal() {
        return nextOptions().isEmpty();
    }

    /** Every status this one is allowed to move to (useful for a dropdown). */
    public List<ApplicationStatus> nextOptions() {
        return Arrays.stream(values()).filter(this::canMoveTo).toList();
    }

    /** Converts text from a form into a status, or throws a friendly ValidationException. */
    public static ApplicationStatus fromString(String text) {
        if (text == null || text.isBlank()) {
            throw new ValidationException("Please choose an application status.");
        }
        try {
            return valueOf(text.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ValidationException("Unknown application status: " + text.trim());
        }
    }
}
