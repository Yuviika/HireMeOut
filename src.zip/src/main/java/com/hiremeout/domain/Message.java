package com.hiremeout.domain;

import java.time.LocalDateTime;

/** One chat message attached to an application, mapped from a row of the messages table. */
public record Message(
        Long id,
        Long applicationId,
        Long senderId,
        String body,
        LocalDateTime sentAt) {
}
