package com.hiremeout.domain;

import java.time.LocalDateTime;

/**
 * An application together with the job and seeker details a dashboard needs to
 * display it, so templates do not have to look anything else up.
 */
public record ApplicationView(
        Long id,
        Long jobId,
        Long seekerId,
        String coverNote,
        String resumeUrl,
        ApplicationStatus status,
        LocalDateTime appliedAt,
        String jobTitle,
        String company,
        String seekerName) {
}
