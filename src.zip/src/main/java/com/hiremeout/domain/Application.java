package com.hiremeout.domain;

import java.time.LocalDateTime;

/** One job application, mapped from a row of the applications table. */
public record Application(
        Long id,
        Long jobId,
        Long seekerId,
        String coverNote,
        String resumeUrl,
        ApplicationStatus status,
        LocalDateTime appliedAt) {
}
