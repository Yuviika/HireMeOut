package com.hiremeout.domain;

/** The three kinds of user in the portal. */
public enum Role {
    SEEKER,
    EMPLOYER,
    ADMIN
}
