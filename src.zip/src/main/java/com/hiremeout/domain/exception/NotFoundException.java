package com.hiremeout.domain.exception;

/** Thrown when something the user asked for does not exist (HTTP 404). */
public class NotFoundException extends PortalException {

    public NotFoundException(String userMessage) {
        super(userMessage, 404);
    }
}
