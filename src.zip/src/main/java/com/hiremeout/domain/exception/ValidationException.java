package com.hiremeout.domain.exception;

/** Thrown when submitted data is missing, malformed or not allowed (HTTP 400). */
public class ValidationException extends PortalException {

    public ValidationException(String userMessage) {
        super(userMessage, 400);
    }
}
