package com.hiremeout.domain.exception;

/** Thrown when the signed-in user is not allowed to do this (HTTP 403). */
public class ForbiddenException extends PortalException {

    public ForbiddenException(String userMessage) {
        super(userMessage, 403);
    }
}
