package com.hiremeout.domain.exception;

/** Thrown when the action clashes with the current state, e.g. applying twice (HTTP 409). */
public class ConflictException extends PortalException {

    public ConflictException(String userMessage) {
        super(userMessage, 409);
    }
}
