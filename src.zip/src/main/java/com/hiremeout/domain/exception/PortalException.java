package com.hiremeout.domain.exception;

/**
 * Base class for every "expected" error in the portal.
 *
 * It carries a friendly message that is safe to show on screen and an HTTP status
 * number (404, 400, ...). The GlobalExceptionHandler (added in a later part) reads
 * both and turns them into an error page. The status is a plain int so the domain
 * layer does not depend on Spring.
 */
public class PortalException extends RuntimeException {

    private final int status;

    public PortalException(String userMessage, int status) {
        super(userMessage);
        this.status = status;
    }

    /** Message that is safe to show to the user. */
    public String getUserMessage() {
        return getMessage();
    }

    /** HTTP status code that best describes this error. */
    public int getStatus() {
        return status;
    }
}
