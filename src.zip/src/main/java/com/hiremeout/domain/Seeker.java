package com.hiremeout.domain;

/** A job seeker. Adds a short profile headline to the shared user data. */
public final class Seeker extends PortalUser {

    private final String headline;

    public Seeker(Long id, String name, String email, String headline) {
        super(id, name, email, Role.SEEKER);
        this.headline = headline;
    }

    public String headline() {
        return headline;
    }

    @Override
    public String dashboardTitle() {
        return "Seeker space";
    }

    @Override
    public String welcomeLine() {
        return "Your next role is out there, " + name() + ".";
    }
}
