package com.hiremeout.domain;

/** An employer. Adds the company name, which is used when posting jobs. */
public final class Employer extends PortalUser {

    private final String company;

    public Employer(Long id, String name, String email, String company) {
        super(id, name, email, Role.EMPLOYER);
        this.company = company;
    }

    public String company() {
        return company;
    }

    @Override
    public String dashboardTitle() {
        return "Employer space";
    }

    @Override
    public String welcomeLine() {
        return "Build a team people want to join.";
    }
}
