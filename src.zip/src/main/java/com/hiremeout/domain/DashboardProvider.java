package com.hiremeout.domain;

/**
 * Anything that can own a dashboard page. Seeker, Employer and Admin all implement
 * this, so code can treat them the same way and still get role-specific text.
 */
public interface DashboardProvider {

    /** Heading shown at the top of the dashboard. */
    String dashboardTitle();

    /** Short greeting line for this role. */
    String welcomeLine();

    /** The role that owns this dashboard. */
    Role role();
}
