package com.hiremeout.domain;

import java.util.List;

/**
 * Everything a dashboard page needs: who owns it, a headline and a typed list of
 * items. The type parameter T is what makes it generic, so a seeker snapshot can
 * hold {@code List<ApplicationView>} while an admin snapshot holds {@code List<Job>}.
 *
 * @param <T> the kind of item shown on the dashboard
 */
public record DashboardSnapshot<T>(DashboardProvider owner, List<T> items, String headline) {

    public DashboardSnapshot {
        items = List.copyOf(items);
    }

    /** Small helper so callers do not need to write "new DashboardSnapshot<>(...)". */
    public static <T> DashboardSnapshot<T> of(DashboardProvider owner, List<T> items, String headline) {
        return new DashboardSnapshot<>(owner, items, headline);
    }
}
