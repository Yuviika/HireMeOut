package com.hiremeout.domain;

/** An admin. Has moderation responsibilities such as approving job postings. */
public final class Admin extends PortalUser {

    public Admin(Long id, String name, String email) {
        super(id, name, email, Role.ADMIN);
    }

    @Override
    public String dashboardTitle() {
        return "Admin space";
    }

    @Override
    public String welcomeLine() {
        return "Keep the talent marketplace trusted.";
    }
}
