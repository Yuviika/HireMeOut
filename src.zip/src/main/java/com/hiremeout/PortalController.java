package com.hiremeout;

import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.messaging.simp.SimpMessagingTemplate;

/**
 * LEGACY controller from the first prototype. It is no longer registered with Spring.
 *
 * <p>Its routes now live in the controllers inside com.hiremeout.controller
 * (HomeController, JobController, DashboardController, ApplicationController,
 * AdminController). Spring would refuse to start if both versions were active,
 * because the same URL cannot be mapped twice, so the {@code @Controller}
 * annotation was removed. The file is kept for reference and can be deleted once
 * you no longer need it.
 *
 * @deprecated replaced by the controllers in com.hiremeout.controller
 */
@Deprecated
public class PortalController {
  private final JdbcTemplate db; private final SimpMessagingTemplate events;
  public PortalController(JdbcTemplate db, SimpMessagingTemplate events){this.db=db;this.events=events;}

  @GetMapping("/") String home(){ return "index"; }
  @GetMapping("/jobs") String jobs(@RequestParam(required=false) String q, Model model){
    String term=q==null?"":q.trim();
    model.addAttribute("jobs", db.queryForList("SELECT id,title,company,location,job_type FROM jobs WHERE status='APPROVED' AND (title LIKE ? OR company LIKE ?) ORDER BY created_at DESC", "%"+term+"%", "%"+term+"%"));
    model.addAttribute("q",term); return "jobs";
  }
  @GetMapping("/demo/{role}") String dashboard(@PathVariable String role, Model model){
    if (!List.of("seeker","employer","admin").contains(role)) return "redirect:/";
    model.addAttribute("role",role); model.addAttribute("jobs",db.queryForList("SELECT * FROM jobs ORDER BY created_at DESC"));
    model.addAttribute("applications",db.queryForList("SELECT a.*,j.title,j.company,u.name seeker_name FROM applications a JOIN jobs j ON j.id=a.job_id JOIN users u ON u.id=a.seeker_id ORDER BY a.applied_at DESC"));
    return "dashboard";
  }
  @PostMapping("/jobs") String postJob(@RequestParam String title,@RequestParam String location,@RequestParam String jobType,@RequestParam String description){
    db.update("INSERT INTO jobs(employer_id,title,company,location,job_type,description,status) VALUES(2,?,?,?,?,?,'PENDING')",title,"Studio North",location,jobType,description);
    events.convertAndSend("/topic/updates",Map.of("type","job","message","A new job is waiting for approval.")); return "redirect:/demo/employer";
  }
  @PostMapping("/jobs/{id}/review") String review(@PathVariable long id,@RequestParam String decision){
    db.update("UPDATE jobs SET status=? WHERE id=?",decision,id); events.convertAndSend("/topic/updates",Map.of("type","approval","message","A job posting was "+decision.toLowerCase()+".")); return "redirect:/demo/admin";
  }
  @PostMapping("/jobs/{id}/apply") String apply(@PathVariable long id,@RequestParam String coverNote){
    try { db.update("INSERT INTO applications(job_id,seeker_id,cover_note,resume_url,status) VALUES(?,1,?,'resume-aarav.pdf','APPLIED')",id,coverNote); }
    catch(Exception ignored) { }
    events.convertAndSend("/topic/updates",Map.of("type","application","message","A candidate applied to a role.")); return "redirect:/demo/seeker";
  }
  @PostMapping("/applications/{id}/status") String updateStatus(@PathVariable long id,@RequestParam String status){
    db.update("UPDATE applications SET status=? WHERE id=?",status,id); events.convertAndSend("/topic/updates",Map.of("type","application","message","An application moved to "+status+".")); return "redirect:/demo/employer";
  }
}
