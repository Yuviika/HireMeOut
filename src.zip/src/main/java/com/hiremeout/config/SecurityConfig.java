package com.hiremeout.config;

import com.hiremeout.domain.PortalUser;
import com.hiremeout.domain.Role;
import com.hiremeout.repository.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRequestAttributeHandler;

/**
 * Defines all HTTP security rules for the portal.
 *
 * <p>Beginners: this class tells Spring Security which URLs are public,
 * which URLs need a specific role, how users log in, and how they log out.
 *
 * <p>Key concepts:
 * <ul>
 *   <li>CSRF protection: prevents malicious sites from submitting forms on behalf of your users.
 *   <li>OAuth2: lets users log in with Google or GitHub instead of a password.
 *   <li>SecurityFilterChain: the chain of checks applied to every request.
 * </ul>
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    /**
     * Google OAuth client-id, injected from application.properties.
     * The default is an empty string, which means Google login is disabled.
     */
    @Value("${spring.security.oauth2.client.registration.google.client-id:}")
    private String googleClientId;

    /**
     * GitHub OAuth client-id, injected from application.properties.
     * The default is an empty string, which means GitHub login is disabled.
     */
    @Value("${spring.security.oauth2.client.registration.github.client-id:}")
    private String githubClientId;

    private final UserRepository userRepository;

    public SecurityConfig(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Builds the security filter chain that is applied to every HTTP request.
     *
     * @param http the builder provided by Spring Security
     * @return the finished SecurityFilterChain
     * @throws Exception if the configuration is invalid
     */
    @Bean
    public SecurityFilterChain security(HttpSecurity http) throws Exception {

        // ── CSRF ──────────────────────────────────────────────────────────────
        // Re-enable CSRF protection for all endpoints.
        // The SockJS WebSocket handshake at /live/** is excluded because SockJS
        // performs its own origin-based check and cannot easily carry a CSRF token.
        // All Thymeleaf forms use th:action, which includes the CSRF token automatically.
        CsrfTokenRequestAttributeHandler csrfHandler = new CsrfTokenRequestAttributeHandler();
        http.csrf(csrf -> csrf
                .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
                .csrfTokenRequestHandler(csrfHandler)
                .ignoringRequestMatchers("/live/**"));

        // ── Authorization rules ───────────────────────────────────────────────
        http.authorizeHttpRequests(auth -> auth

                // Public resources: anyone may access these without logging in.
                .requestMatchers(
                        "/",
                        "/css/**",
                        "/js/**",
                        "/live/**",
                        "/demo-login/**",
                        "/oauth2/**",
                        "/login/**",
                        "/error",
                        "/oauth-error",
                        "/favicon.ico"
                ).permitAll()

                // GET /jobs (browse jobs list) is public.
                .requestMatchers(HttpMethod.GET, "/jobs").permitAll()

                // Seeker-only routes.
                .requestMatchers("/dashboard/seeker").hasRole("SEEKER")
                .requestMatchers("/jobs/*/apply").hasRole("SEEKER")

                // Employer-only routes.
                .requestMatchers("/dashboard/employer").hasRole("EMPLOYER")
                .requestMatchers(HttpMethod.POST, "/jobs").hasRole("EMPLOYER")
                .requestMatchers("/applications/*/status").hasRole("EMPLOYER")

                // Admin-only routes.
                .requestMatchers("/dashboard/admin").hasRole("ADMIN")
                .requestMatchers("/jobs/*/review").hasRole("ADMIN")

                // Messages are accessible to authenticated users (service enforces participant check).
                .requestMatchers("/applications/*/messages").authenticated()

                // Every other request needs the user to be logged in.
                .anyRequest().authenticated()
        );

        // ── Anonymous users ───────────────────────────────────────────────────
        // Someone who is not signed in and opens a protected page is sent to the
        // home page (where the role cards are) with ?signin so it can say why.
        // Signed-in users who lack the right role still get the normal 403 page.
        http.exceptionHandling(exceptions -> exceptions
                .authenticationEntryPoint(new LoginUrlAuthenticationEntryPoint("/?signin")));

        // ── Logout ────────────────────────────────────────────────────────────
        // POST /logout clears the session and the security context, then
        // redirects back to the home page.
        http.logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/")
                .invalidateHttpSession(true)
                .clearAuthentication(true)
        );

        // ── OAuth2 login ──────────────────────────────────────────────────────
        // Enable oauth2Login only when at least one provider is configured.
        boolean googleConfigured = googleClientId != null && !googleClientId.isBlank();
        boolean githubConfigured = githubClientId != null && !githubClientId.isBlank();

        if (googleConfigured || githubConfigured) {
            http.oauth2Login(oauth2 -> oauth2
                    .loginPage("/")
                    .successHandler((request, response, authentication) -> {

                        // Look up (or create) the portal user by email.
                        OAuth2User oauthUser = (OAuth2User) authentication.getPrincipal();
                        String email = oauthUser.getAttribute("email");

                        if (email == null || email.isBlank()) {
                            // The provider did not share an email (GitHub privacy setting).
                            response.sendRedirect("/oauth-error");
                            return;
                        }

                        // Find existing user or create a new SEEKER.
                        PortalUser portalUser = userRepository.findByEmail(email)
                                .orElseGet(() -> {
                                    String name = oauthUser.getAttribute("name");
                                    String safeName = (name != null) ? name : email;
                                    return userRepository.create(safeName, email, Role.SEEKER, null, null);
                                });

                        // Build and store our AppUser as the new principal.
                        AppUser appUser = new AppUser(portalUser.id(), portalUser.name(), portalUser.role());

                        org.springframework.security.authentication.UsernamePasswordAuthenticationToken token =
                                new org.springframework.security.authentication.UsernamePasswordAuthenticationToken(
                                        appUser,
                                        null,
                                        java.util.List.of(new SimpleGrantedAuthority("ROLE_" + portalUser.role().name()))
                                );

                        org.springframework.security.core.context.SecurityContextHolder
                                .getContext().setAuthentication(token);

                        request.getSession().setAttribute(
                                org.springframework.security.web.context.HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY,
                                org.springframework.security.core.context.SecurityContextHolder.getContext()
                        );

                        // Redirect to the correct dashboard.
                        String destination = switch (portalUser.role()) {
                            case SEEKER -> "/dashboard/seeker";
                            case EMPLOYER -> "/dashboard/employer";
                            case ADMIN -> "/dashboard/admin";
                        };
                        response.sendRedirect(destination);
                    })
            );
        }

        return http.build();
    }
}
