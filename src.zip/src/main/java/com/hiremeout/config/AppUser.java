package com.hiremeout.config;

import com.hiremeout.domain.Role;
import java.util.Collection;
import java.util.List;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * The principal object that Spring Security stores in the session for a logged-in user.
 *
 * <p>It wraps the three pieces of information the rest of the app needs: the
 * database id, the display name, and the role. Implementing {@link UserDetails}
 * lets Spring Security treat it as a first-class principal directly.
 *
 * <p>Beginners: "principal" just means "who is logged in right now."
 */
public class AppUser implements UserDetails {

    private final Long userId;
    private final String displayName;
    private final Role role;

    /**
     * Creates an AppUser.
     *
     * @param userId      the primary key from the users table
     * @param displayName the human-readable name to show in the UI
     * @param role        the portal role (SEEKER, EMPLOYER, or ADMIN)
     */
    public AppUser(Long userId, String displayName, Role role) {
        this.userId = userId;
        this.displayName = displayName;
        this.role = role;
    }

    /** The database primary key for this user. */
    public Long userId() {
        return userId;
    }

    /** The human-readable name (used in welcome messages). */
    public String displayName() {
        return displayName;
    }

    /** The portal role this user has. */
    public Role role() {
        return role;
    }

    /**
     * JavaBean-style getters. Thymeleaf expressions such as
     * {@code ${#authentication.principal.displayName}} look for a method called
     * getDisplayName(), so these mirror the short accessors above.
     */
    public Long getUserId() {
        return userId;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Role getRole() {
        return role;
    }

    /**
     * Returns the single Spring Security authority for this user.
     * The prefix "ROLE_" is required by Spring Security for hasRole() checks.
     * For example, Role.SEEKER becomes the authority "ROLE_SEEKER".
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + role.name()));
    }

    /**
     * We do not store passwords — login is done via demo login or OAuth2.
     * Returning an empty string satisfies the interface contract.
     */
    @Override
    public String getPassword() {
        return "";
    }

    /**
     * Spring Security uses getUsername() to identify the principal.
     * We use the user id as a stable, unique identifier.
     */
    @Override
    public String getUsername() {
        return String.valueOf(userId);
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
