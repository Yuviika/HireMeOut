package com.hiremeout.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * Sets up the STOMP over WebSocket broker that pushes live events to dashboards.
 *
 * <p>Beginners: WebSocket keeps an open connection between the browser and the server
 * so the server can push a message the moment something interesting happens, without
 * the browser having to ask again and again.
 *
 * <p>The SockJS fallback means older browsers that don't support WebSocket get a
 * long-polling fallback automatically.
 *
 * <p>The allowed-origins property controls which domains may connect. In production,
 * set {@code app.allowed-origins} in application.properties to your real domain.
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    /**
     * Comma-separated list of origins that are allowed to open a WebSocket
     * connection. Defaults to http://localhost:8080 for local development.
     *
     * <p>Set {@code app.allowed-origins=https://yourdomain.com} in production.
     */
    @Value("${app.allowed-origins:http://localhost:8080}")
    private String allowedOrigins;

    /**
     * Configures the in-memory message broker.
     * Messages published to /topic/... are broadcast to all subscribed clients.
     */
    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.enableSimpleBroker("/topic");
    }

    /**
     * Registers the STOMP endpoint that the browser connects to.
     * SockJS provides an automatic fallback for browsers without WebSocket.
     */
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        String[] origins = allowedOrigins.split(",");

        for (int i = 0; i < origins.length; i++) {
            origins[i] = origins[i].trim();
        }

        registry.addEndpoint("/live")
                .setAllowedOrigins(origins)
                .withSockJS();
    }
}
