package com.hiremeout.config;

import java.util.Optional;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * A small helper that retrieves the currently logged-in {@link AppUser} from
 * the Spring Security context.
 *
 * <p>Controllers and services can call {@code CurrentUser.get()} instead of
 * reaching into Spring Security directly. This makes the code easier to read
 * and easier to test (just mock the security context).
 *
 * <p>Beginners: the SecurityContext is like a thread-local sticky note that
 * remembers who is logged in for the current request.
 */
public final class CurrentUser {

    private CurrentUser() {
        // Utility class — do not instantiate.
    }

    /**
     * Returns the logged-in user, or empty if the request is anonymous.
     *
     * @return an Optional containing the AppUser, or empty if nobody is logged in
     */
    public static Optional<AppUser> get() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null) {
            return Optional.empty();
        }

        if (!authentication.isAuthenticated()) {
            return Optional.empty();
        }

        Object principal = authentication.getPrincipal();

        if (principal instanceof AppUser appUser) {
            return Optional.of(appUser);
        }

        return Optional.empty();
    }

    /**
     * Returns the logged-in user, throwing an exception if nobody is logged in.
     *
     * <p>Use this only inside routes that are already protected by the security
     * filter, so you know a user is always present.
     *
     * @return the AppUser for the current request
     * @throws IllegalStateException if no user is authenticated
     */
    public static AppUser require() {
        return get().orElseThrow(() ->
                new IllegalStateException("This route requires an authenticated user."));
    }
}
