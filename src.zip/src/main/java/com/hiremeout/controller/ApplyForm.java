package com.hiremeout.controller;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Form data sent when a seeker applies to a job.
 *
 * <p>Only the cover note is collected from the form. The resume URL defaults to
 * an empty string for now (a real app would have file upload in a later part).
 *
 * <p>Beginner note: {@code @NotBlank} prevents empty strings, and {@code @Size}
 * limits the length. Both are checked by Spring before the handler runs.
 */
public record ApplyForm(

        @NotBlank(message = "Please write a short cover note.")
        @Size(max = 2000, message = "Cover note must be 2000 characters or fewer.")
        String coverNote
) {

    // JavaBean-style getters. Thymeleaf's th:field reads form values through
    // getXxx() methods, which records do not generate on their own. The shorter
    // record accessors (title(), body() ...) keep working as before.

    public String getCoverNote() {
        return coverNote;
    }
}
