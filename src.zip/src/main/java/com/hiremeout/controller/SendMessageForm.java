package com.hiremeout.controller;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Form data sent when a user posts a message on an application thread.
 *
 * <p>The limit matches {@code MessageService.BODY_MAX} (2000 characters).
 */
public record SendMessageForm(

        @NotBlank(message = "Message cannot be empty.")
        @Size(max = 2000, message = "Message must be 2000 characters or fewer.")
        String body
) {

    // JavaBean-style getters. Thymeleaf's th:field reads form values through
    // getXxx() methods, which records do not generate on their own. The shorter
    // record accessors (title(), body() ...) keep working as before.

    public String getBody() {
        return body;
    }
}
