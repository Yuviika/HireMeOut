package com.hiremeout.controller;

import com.hiremeout.config.AppUser;
import com.hiremeout.domain.PortalUser;
import com.hiremeout.domain.Role;
import com.hiremeout.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import java.util.Optional;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * Handles demo login — a quick way to try each role without setting up an OAuth app.
 *
 * <p>Each role card on the home page posts to {@code /demo-login/{role}}.
 * This controller looks up the matching demo user in the database (Aarav for
 * seeker, Maya for employer, Riya for admin), builds an {@link AppUser} principal,
 * and saves it in the HTTP session so Spring Security remembers the user.
 *
 * <p>Beginners: this is NOT how a real login works — real logins use passwords or
 * OAuth tokens. The demo login is only for exploring the app locally.
 */
@Controller
public class DemoLoginController {

    private final UserRepository userRepository;

    public DemoLoginController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Logs in as the demo user for the given role and redirects to their dashboard.
     *
     * <p>The CSRF token is included automatically because the home page forms
     * use {@code th:action}, which adds the Thymeleaf-managed CSRF input.
     *
     * @param roleName "seeker", "employer", or "admin"
     * @param session  the HTTP session used to persist the security context
     * @param model    used to pass an error message if the demo user is missing
     * @return a redirect to the correct dashboard, or the error template
     */
    @PostMapping("/demo-login/{role}")
    public String demoLogin(
            @PathVariable("role") String roleName,
            HttpSession session,
            Model model) {

        // Parse and validate the role name from the URL.
        Role role;
        try {
            role = Role.valueOf(roleName.toUpperCase());
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", "Unknown demo role: " + roleName);
            return "demo-error";
        }

        // Look up the demo user for this role. There should be exactly one per role.
        Optional<PortalUser> maybeUser = userRepository.findOneByRole(role);

        if (maybeUser.isEmpty()) {
            model.addAttribute("error",
                    "No demo user found for role " + role.name() +
                    ". Make sure data.sql has been loaded.");
            return "demo-error";
        }

        PortalUser portalUser = maybeUser.get();

        // Build our AppUser principal.
        AppUser appUser = new AppUser(portalUser.id(), portalUser.name(), portalUser.role());

        // Build an Authentication object with the ROLE_ authority.
        Authentication authentication = new UsernamePasswordAuthenticationToken(
                appUser,
                null,
                java.util.List.of(new SimpleGrantedAuthority("ROLE_" + portalUser.role().name()))
        );

        // Store the authentication in the SecurityContext.
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        securityContext.setAuthentication(authentication);
        SecurityContextHolder.setContext(securityContext);

        // Save the SecurityContext into the HTTP session so it survives across requests.
        session.setAttribute(
                HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY,
                securityContext
        );

        // Redirect the user to the correct dashboard.
        String destination = switch (portalUser.role()) {
            case SEEKER -> "/dashboard/seeker";
            case EMPLOYER -> "/dashboard/employer";
            case ADMIN -> "/dashboard/admin";
        };

        return "redirect:" + destination;
    }
}
