package com.hiremeout.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

/**
 * Adds a few values every page needs (in the navigation bar) without each
 * controller having to remember to add them.
 *
 * <p>Right now it tells the templates whether Google and GitHub sign-in are
 * configured, so the nav only shows login buttons that will actually work.
 */
@ControllerAdvice
public class LayoutModelAdvice {

    @Value("${spring.security.oauth2.client.registration.google.client-id:}")
    private String googleClientId;

    @Value("${spring.security.oauth2.client.registration.github.client-id:}")
    private String githubClientId;

    /** True when a Google client id is configured in application.properties. */
    @ModelAttribute("googleLoginEnabled")
    public boolean googleLoginEnabled() {
        return googleClientId != null && !googleClientId.isBlank();
    }

    /** True when a GitHub client id is configured in application.properties. */
    @ModelAttribute("githubLoginEnabled")
    public boolean githubLoginEnabled() {
        return githubClientId != null && !githubClientId.isBlank();
    }
}
