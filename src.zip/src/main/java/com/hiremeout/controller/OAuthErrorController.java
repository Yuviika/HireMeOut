package com.hiremeout.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Handles the error page shown when OAuth login fails because the identity
 * provider did not share the user's email address.
 *
 * <p>GitHub, for example, lets users hide their email address. If no email is
 * returned we cannot look up or create a portal user, so we show this friendly
 * page instead of letting the app crash with a NullPointerException.
 */
@Controller
public class OAuthErrorController {

    /**
     * Shows a friendly explanation of why OAuth login did not work.
     *
     * @param model used to add the error explanation for the template
     * @return the name of the Thymeleaf template to render
     */
    @GetMapping("/oauth-error")
    public String oauthError(Model model) {
        model.addAttribute(
                "error",
                "Your identity provider did not share your email address. " +
                "Please make your email public in your GitHub or Google settings and try again, " +
                "or use demo login instead."
        );
        return "demo-error";
    }
}
