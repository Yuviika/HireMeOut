package com.hiremeout.controller;

import com.hiremeout.config.CurrentUser;
import com.hiremeout.domain.ApplicationStatus;
import com.hiremeout.domain.exception.PortalException;
import com.hiremeout.service.ApplicationService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Handles job applications (seeker applies) and application status changes
 * (employer moves a candidate forward).
 *
 * <p>The SecurityConfig has already ensured that only SEEKER can reach
 * POST /jobs/{id}/apply, and only EMPLOYER can reach POST /applications/{id}/status.
 *
 * <p>Business rule problems (for example "you already applied") are shown as a
 * message on the dashboard instead of a full error page.
 */
@Controller
public class ApplicationController {

    private final ApplicationService applicationService;

    public ApplicationController(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    /**
     * Submits a new application from the logged-in seeker.
     *
     * @param jobId  the job the seeker wants to apply to
     * @param form   the cover note, validated by {@code @Valid}
     * @param result validation errors, if any
     * @param ra     used to pass flash messages across the redirect
     * @return a redirect to the seeker dashboard
     */
    @PostMapping("/jobs/{id}/apply")
    public String apply(
            @PathVariable("id") Long jobId,
            @Valid @ModelAttribute("applyForm") ApplyForm form,
            BindingResult result,
            RedirectAttributes ra) {

        if (result.hasErrors()) {
            ra.addFlashAttribute("flashError", result.getAllErrors().get(0).getDefaultMessage());
            return "redirect:/dashboard/seeker";
        }

        try {
            Long seekerId = CurrentUser.require().userId();
            // No resume file upload yet — leave the URL empty for now.
            applicationService.apply(seekerId, jobId, form.coverNote().trim(), "");
            ra.addFlashAttribute("success", "Application submitted! Good luck.");
        } catch (PortalException e) {
            ra.addFlashAttribute("flashError", e.getUserMessage());
        }

        return "redirect:/dashboard/seeker";
    }

    /**
     * Moves an application to a new status (called by the employer's dashboard).
     *
     * @param applicationId the application to update
     * @param statusText    the new status string, e.g. "REVIEWING" or "OFFER"
     * @param ra            used to pass flash messages across the redirect
     * @return a redirect to the employer dashboard
     */
    @PostMapping("/applications/{id}/status")
    public String changeStatus(
            @PathVariable("id") Long applicationId,
            @RequestParam("status") String statusText,
            RedirectAttributes ra) {

        try {
            ApplicationStatus next = ApplicationStatus.fromString(statusText);
            Long employerId = CurrentUser.require().userId();
            applicationService.changeStatus(employerId, applicationId, next);
            ra.addFlashAttribute("success", "Application moved to \"" + next.label() + "\".");
        } catch (PortalException e) {
            ra.addFlashAttribute("flashError", e.getUserMessage());
        }

        return "redirect:/dashboard/employer";
    }
}
