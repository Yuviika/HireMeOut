package com.hiremeout.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Serves the public home page at "/".
 *
 * <p>Beginner note: this is the first controller a visitor hits. It just
 * returns the name of the Thymeleaf template to render — no data needed
 * because the home page content is static HTML.
 */
@Controller
public class HomeController {

    /**
     * Shows the landing page.
     *
     * @return the name of the Thymeleaf template ("index" → templates/index.html)
     */
    @GetMapping("/")
    public String home() {
        return "index";
    }

    /**
     * Keeps old bookmarks working. The first prototype used /demo/seeker,
     * /demo/employer and /demo/admin; those now forward to the real dashboards.
     * Security then decides whether the visitor may actually see them.
     *
     * @param role the last part of the old URL
     * @return a redirect to the matching dashboard, or to the home page
     */
    @GetMapping("/demo/{role}")
    public String legacyDemoLink(@PathVariable("role") String role) {
        return switch (role) {
            case "seeker", "employer", "admin" -> "redirect:/dashboard/" + role;
            default -> "redirect:/";
        };
    }
}
