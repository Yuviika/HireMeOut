package com.hiremeout.controller;

import com.hiremeout.config.AppUser;
import com.hiremeout.config.CurrentUser;
import com.hiremeout.domain.ApplicationStatus;
import com.hiremeout.domain.ApplicationView;
import com.hiremeout.domain.DashboardSnapshot;
import com.hiremeout.domain.Job;
import com.hiremeout.domain.JobStatus;
import com.hiremeout.domain.Role;
import com.hiremeout.domain.exception.ForbiddenException;
import com.hiremeout.service.DashboardService;
import com.hiremeout.service.JobService;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Serves role-specific dashboard pages at /dashboard/{role}.
 *
 * <p>Each role sees a different view of the data, built by
 * {@link DashboardService}. The controller also checks that the logged-in
 * user's role matches the URL segment, so a seeker cannot type
 * /dashboard/admin and see the admin's data.
 *
 * <p>Beginner note: the SecurityConfig handles the coarse-grained check
 * (e.g. only EMPLOYER can reach /dashboard/employer). This controller does
 * the fine-grained check that the role in the URL matches the session role.
 * It also prepares the small numbers (counts) shown on the stat cards.
 */
@Controller
public class DashboardController {

    private final DashboardService dashboardService;
    private final JobService jobService;

    public DashboardController(DashboardService dashboardService, JobService jobService) {
        this.dashboardService = dashboardService;
        this.jobService = jobService;
    }

    /**
     * Renders the correct dashboard for the given role.
     *
     * @param roleSlug "seeker", "employer", or "admin"
     * @param model    used to pass the snapshot and supporting data to the template
     * @return the name of the shared "dashboard" template
     * @throws ForbiddenException if the URL role does not match the logged-in user's role
     */
    @GetMapping("/dashboard/{role}")
    public String dashboard(@PathVariable("role") String roleSlug, Model model) {
        AppUser appUser = CurrentUser.require();
        Role expectedRole = parseRole(roleSlug);

        // Make sure the logged-in user owns this dashboard.
        if (appUser.role() != expectedRole) {
            throw new ForbiddenException("You cannot view another role's dashboard.");
        }

        switch (expectedRole) {
            case SEEKER -> buildSeekerDashboard(appUser.userId(), model);
            case EMPLOYER -> buildEmployerDashboard(appUser.userId(), model);
            case ADMIN -> buildAdminDashboard(appUser.userId(), model);
        }

        // Always lower-case so the template can compare it with 'seeker', 'employer', 'admin'.
        model.addAttribute("role", expectedRole.name().toLowerCase());
        return "dashboard";
    }

    private void buildSeekerDashboard(Long userId, Model model) {
        DashboardSnapshot<ApplicationView> snapshot = dashboardService.seekerDashboard(userId);
        List<ApplicationView> applications = snapshot.items();

        // Only offer jobs this seeker has NOT applied to yet (a second application would be rejected).
        Set<Long> appliedJobIds = applications.stream()
                .map(ApplicationView::jobId)
                .collect(Collectors.toSet());
        List<Job> openJobs = jobService.listApproved("").stream()
                .filter(job -> !appliedJobIds.contains(job.id()))
                .toList();

        long activeCount = applications.stream()
                .filter(application -> !application.status().isTerminal())
                .count();
        long offerCount = applications.stream()
                .filter(application -> application.status() == ApplicationStatus.OFFER)
                .count();

        model.addAttribute("snapshot", snapshot);
        model.addAttribute("approvedJobs", openJobs);
        model.addAttribute("activeCount", activeCount);
        model.addAttribute("offerCount", offerCount);
    }

    private void buildEmployerDashboard(Long userId, Model model) {
        DashboardSnapshot<ApplicationView> snapshot = dashboardService.employerDashboard(userId);
        List<Job> myJobs = jobService.listByEmployer(userId);

        long liveJobCount = myJobs.stream()
                .filter(job -> job.status() == JobStatus.APPROVED)
                .count();
        long pendingJobCount = myJobs.stream()
                .filter(job -> job.status() == JobStatus.PENDING)
                .count();

        model.addAttribute("snapshot", snapshot);
        model.addAttribute("myJobs", myJobs);
        model.addAttribute("liveJobCount", liveJobCount);
        model.addAttribute("pendingJobCount", pendingJobCount);

        // After a failed submit the controller sends the user's input back as a flash attribute.
        if (!model.containsAttribute(JobController.FORM_NAME)) {
            model.addAttribute(JobController.FORM_NAME, new PostJobForm("", "", "Full-time", ""));
        }
    }

    private void buildAdminDashboard(Long userId, Model model) {
        DashboardSnapshot<Job> snapshot = dashboardService.adminDashboard(userId);
        List<Job> allJobs = snapshot.items();

        List<Job> pendingJobs = allJobs.stream()
                .filter(job -> job.status() == JobStatus.PENDING)
                .toList();
        List<Job> reviewedJobs = allJobs.stream()
                .filter(job -> job.status() != JobStatus.PENDING)
                .toList();
        long approvedCount = allJobs.stream()
                .filter(job -> job.status() == JobStatus.APPROVED)
                .count();
        long rejectedCount = allJobs.stream()
                .filter(job -> job.status() == JobStatus.REJECTED)
                .count();

        model.addAttribute("snapshot", snapshot);
        model.addAttribute("pendingJobs", pendingJobs);
        model.addAttribute("reviewedJobs", reviewedJobs);
        model.addAttribute("approvedCount", approvedCount);
        model.addAttribute("rejectedCount", rejectedCount);
    }

    /**
     * Converts a URL path segment ("seeker") to the Role enum (Role.SEEKER).
     * Throws ForbiddenException on an unknown slug so the user sees a friendly error.
     */
    private Role parseRole(String slug) {
        try {
            return Role.valueOf(slug.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ForbiddenException("Unknown dashboard role: " + slug);
        }
    }
}
