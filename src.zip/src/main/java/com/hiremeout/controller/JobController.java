package com.hiremeout.controller;

import com.hiremeout.config.CurrentUser;
import com.hiremeout.domain.Job;
import com.hiremeout.domain.exception.PortalException;
import com.hiremeout.service.JobService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Handles the public job board (GET /jobs) and job posting (POST /jobs).
 *
 * <p>GET /jobs is public — any visitor may search and browse approved jobs.
 * POST /jobs is employer-only — the SecurityConfig enforces that rule; this
 * controller just does the work once security has already passed the request.
 */
@Controller
public class JobController {

    /** Name used for the post-a-job form in every template and controller. */
    static final String FORM_NAME = "postJobForm";

    private static final String BINDING_RESULT_PREFIX = "org.springframework.validation.BindingResult.";

    private final JobService jobService;

    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    /**
     * Shows the public list of approved jobs, optionally filtered by a search term.
     *
     * @param q     the optional search query from the URL (e.g. /jobs?q=java)
     * @param model used to pass jobs and the search term to the template
     * @return the name of the Thymeleaf template to render
     */
    @GetMapping("/jobs")
    public String listJobs(@RequestParam(required = false) String q, Model model) {
        String term = (q == null) ? "" : q.trim();
        List<Job> jobs = jobService.listApproved(term);

        model.addAttribute("jobs", jobs);
        model.addAttribute("q", term);

        // Employers also see the post-a-role form on this page, so it needs a form object.
        if (!model.containsAttribute(FORM_NAME)) {
            model.addAttribute(FORM_NAME, new PostJobForm("", "", "Full-time", ""));
        }

        return "jobs";
    }

    /**
     * Accepts a job posting from an employer.
     *
     * <p>Bean Validation runs first. If the form is invalid, the employer is sent
     * back to their dashboard with the error messages and what they typed
     * (this "redirect, then show errors" pattern avoids re-submitting on refresh).
     *
     * @param form   the submitted form data, already validated by {@code @Valid}
     * @param result the validation result (contains any field errors)
     * @param ra     used to pass messages and the form across the redirect
     * @return a redirect to the employer dashboard
     */
    @PostMapping("/jobs")
    public String postJob(
            @Valid @ModelAttribute(FORM_NAME) PostJobForm form,
            BindingResult result,
            RedirectAttributes ra) {

        if (result.hasErrors()) {
            keepFormForRedisplay(ra, form, result);
            return "redirect:/dashboard/employer";
        }

        try {
            Long employerId = CurrentUser.require().userId();
            jobService.postJob(employerId, form.title(), form.location(), form.jobType(), form.description());
            ra.addFlashAttribute("success", "Job posted! It is waiting for admin approval.");
        } catch (PortalException e) {
            ra.addFlashAttribute("flashError", e.getUserMessage());
            ra.addFlashAttribute(FORM_NAME, form);
        }

        return "redirect:/dashboard/employer";
    }

    private void keepFormForRedisplay(RedirectAttributes ra, PostJobForm form, BindingResult result) {
        ra.addFlashAttribute(BINDING_RESULT_PREFIX + FORM_NAME, result);
        ra.addFlashAttribute(FORM_NAME, form);
        ra.addFlashAttribute("flashError", "Please fix the highlighted fields and try again.");
    }
}
