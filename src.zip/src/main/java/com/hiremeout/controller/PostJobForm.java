package com.hiremeout.controller;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Form data sent when an employer posts a new job.
 *
 * <p>This is a Java record, which is like a short data class: it generates the
 * constructor, getters, equals, hashCode and toString automatically.
 *
 * <p>The {@code @NotBlank} and {@code @Size} annotations are Bean Validation
 * constraints. Spring checks them before the controller method runs. If anything
 * is invalid, the form is shown again with error messages instead of crashing.
 *
 * <p>The size limits here match the VARCHAR lengths in schema.sql.
 */
public record PostJobForm(

        @NotBlank(message = "Job title is required.")
        @Size(max = 140, message = "Job title must be 140 characters or fewer.")
        String title,

        @NotBlank(message = "Location is required.")
        @Size(max = 120, message = "Location must be 120 characters or fewer.")
        String location,

        @NotBlank(message = "Job type is required.")
        @Size(max = 40, message = "Job type must be 40 characters or fewer.")
        String jobType,

        @NotBlank(message = "Please describe the role.")
        String description
) {

    // JavaBean-style getters. Thymeleaf's th:field reads form values through
    // getXxx() methods, which records do not generate on their own. The shorter
    // record accessors (title(), body() ...) keep working as before.

    public String getTitle() {
        return title;
    }

    public String getLocation() {
        return location;
    }

    public String getJobType() {
        return jobType;
    }

    public String getDescription() {
        return description;
    }
}
