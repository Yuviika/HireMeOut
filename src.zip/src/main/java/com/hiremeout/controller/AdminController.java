package com.hiremeout.controller;

import com.hiremeout.config.CurrentUser;
import com.hiremeout.domain.JobStatus;
import com.hiremeout.domain.exception.PortalException;
import com.hiremeout.service.JobService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Handles admin job review: approve or reject a pending job.
 *
 * <p>Only users with ROLE_ADMIN can reach this endpoint — the SecurityConfig
 * enforces that. This controller converts the form value to a {@link JobStatus}
 * and delegates the business logic to {@link JobService}.
 */
@Controller
public class AdminController {

    private final JobService jobService;

    public AdminController(JobService jobService) {
        this.jobService = jobService;
    }

    /**
     * Approves or rejects a job posting.
     *
     * @param jobId    the id of the job to review
     * @param decision "APPROVED" or "REJECTED"
     * @param ra       used to pass a flash message after the redirect
     * @return a redirect to the admin dashboard
     */
    @PostMapping("/jobs/{id}/review")
    public String review(
            @PathVariable("id") Long jobId,
            @RequestParam("decision") String decision,
            RedirectAttributes ra) {

        try {
            JobStatus status = JobStatus.fromString(decision);
            Long adminId = CurrentUser.require().userId();
            jobService.review(adminId, jobId, status);
            ra.addFlashAttribute("success", "Job " + status.name().toLowerCase() + ".");
        } catch (PortalException e) {
            ra.addFlashAttribute("flashError", e.getUserMessage());
        }

        return "redirect:/dashboard/admin";
    }
}
