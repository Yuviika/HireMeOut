package com.hiremeout.controller;

import com.hiremeout.domain.exception.PortalException;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.resource.NoResourceFoundException;

/**
 * Catches exceptions from any controller and turns them into a friendly HTML error page.
 *
 * <p>Two things this class prevents:
 * <ol>
 *   <li>Stack traces leaking to the browser (a security risk).
 *   <li>Spring's default white-label error page appearing for business errors.
 * </ol>
 *
 * <p>Beginner note: {@code @ControllerAdvice} means "apply these handlers to
 * every controller in the application." {@code @ExceptionHandler} says which
 * exception type to catch.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOG = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handles all our own {@link PortalException} subclasses.
     *
     * <p>Each subclass carries the right HTTP status (404, 400, 403, 409) and
     * a user-friendly message. We set those on the response and pass the message
     * to the template so the user sees something meaningful.
     *
     * @param exception the caught exception
     * @param response  used to set the HTTP status code
     * @param model     used to pass the error message to the template
     * @return the name of the error template to render
     */
    @ExceptionHandler(PortalException.class)
    public String handlePortalException(
            PortalException exception,
            HttpServletResponse response,
            Model model) {

        response.setStatus(exception.getStatus());
        model.addAttribute("error", exception.getUserMessage());
        model.addAttribute("userMessage", exception.getUserMessage());
        model.addAttribute("statusCode", exception.getStatus());
        model.addAttribute("statusLabel", labelFor(exception.getStatus()));
        return "error";
    }

    /**
     * Handles URLs that do not exist (a mistyped address, a missing image...).
     * Without this, the catch-all below would report them as a 500 server error.
     *
     * @param response used to set the HTTP 404 status
     * @param model    used to pass the message to the template
     * @return the error template
     */
    @ExceptionHandler(NoResourceFoundException.class)
    public String handleMissingPage(HttpServletResponse response, Model model) {
        String message = "We couldn't find that page. It may have moved, or the address has a typo.";
        response.setStatus(404);
        model.addAttribute("error", message);
        model.addAttribute("userMessage", message);
        model.addAttribute("statusCode", 404);
        model.addAttribute("statusLabel", labelFor(404));
        return "error";
    }

    /**
     * Catches any other unexpected exception so we never show a stack trace.
     *
     * <p>The message shown to the user is always generic — never the internal
     * exception message — to avoid leaking implementation details.
     *
     * @param response used to set the HTTP 500 status
     * @param model    used to pass a generic message to the template
     * @return the error template
     */
    @ExceptionHandler(Exception.class)
    public String handleUnexpectedException(
            Exception exception,
            HttpServletResponse response,
            Model model) {

        // Log internally (with the stack trace) so developers can diagnose the problem,
        // while the browser only ever sees the generic message below.
        LOG.error("Unexpected error while handling a request", exception);

        String message = "Something went wrong on our end. Please try again in a moment.";
        response.setStatus(500);
        model.addAttribute("error", message);
        model.addAttribute("userMessage", message);
        model.addAttribute("statusCode", 500);
        model.addAttribute("statusLabel", "Internal Server Error");
        return "error";
    }

    /**
     * Returns a human-readable label for a common HTTP status code.
     *
     * @param status the HTTP status integer
     * @return a short English description
     */
    private String labelFor(int status) {
        return switch (status) {
            case 400 -> "Bad Request";
            case 403 -> "Forbidden";
            case 404 -> "Not Found";
            case 409 -> "Conflict";
            default -> "Error";
        };
    }
}
