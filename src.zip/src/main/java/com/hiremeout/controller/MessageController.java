package com.hiremeout.controller;

import com.hiremeout.config.AppUser;
import com.hiremeout.config.CurrentUser;
import com.hiremeout.domain.Application;
import com.hiremeout.domain.Message;
import com.hiremeout.repository.ApplicationRepository;
import com.hiremeout.service.MessageService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Shows and sends messages on an application's message thread.
 *
 * <p>Only the seeker who applied and the employer who owns the job may view or
 * send messages. That check is enforced inside {@link MessageService}, which
 * throws {@link com.hiremeout.domain.exception.ForbiddenException} if an
 * outsider tries to read someone else's thread.
 *
 * <p>Routes:
 * <ul>
 *   <li>GET  /applications/{id}/messages — view the thread
 *   <li>POST /applications/{id}/messages — send a new message
 * </ul>
 */
@Controller
public class MessageController {

    private final MessageService messageService;
    private final ApplicationRepository applicationRepository;

    public MessageController(MessageService messageService, ApplicationRepository applicationRepository) {
        this.messageService = messageService;
        this.applicationRepository = applicationRepository;
    }

    /**
     * Shows the message thread for one application.
     *
     * @param applicationId the application whose messages to display
     * @param model         used to pass messages and the send form to the template
     * @return the "messages" template
     */
    @GetMapping("/applications/{id}/messages")
    public String viewThread(@PathVariable("id") Long applicationId, Model model) {
        AppUser viewer = CurrentUser.require();
        List<Message> messages = messageService.list(applicationId, viewer.userId());

        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new com.hiremeout.domain.exception.NotFoundException("Application not found."));

        model.addAttribute("messages", messages);
        model.addAttribute("applicationId", applicationId);
        model.addAttribute("application", application);
        model.addAttribute("currentUserId", viewer.userId());

        if (!model.containsAttribute("form")) {
            model.addAttribute("form", new SendMessageForm(""));
        }

        return "messages";
    }

    /**
     * Sends a new message on an application's thread.
     *
     * <p>On validation failure the thread is re-displayed with the error and the
     * user's typed text, so they do not lose what they wrote.
     *
     * @param applicationId the application this message belongs to
     * @param form          the validated form data
     * @param result        any validation errors
     * @param ra            used for flash messages after a redirect
     * @return a redirect back to the thread on success, or re-renders the page on error
     */
    @PostMapping("/applications/{id}/messages")
    public String sendMessage(
            @PathVariable("id") Long applicationId,
            @Valid @ModelAttribute("form") SendMessageForm form,
            BindingResult result,
            Model model,
            RedirectAttributes ra) {

        if (result.hasErrors()) {
            // Re-display the thread page, keeping the user's typed text.
            AppUser viewer = CurrentUser.require();
            List<Message> messages = messageService.list(applicationId, viewer.userId());
            Application application = applicationRepository.findById(applicationId)
                    .orElseThrow(() -> new com.hiremeout.domain.exception.NotFoundException("Application not found."));

            model.addAttribute("messages", messages);
            model.addAttribute("applicationId", applicationId);
            model.addAttribute("application", application);
            model.addAttribute("currentUserId", viewer.userId());
            return "messages";
        }

        Long senderId = CurrentUser.require().userId();
        messageService.send(senderId, applicationId, form.body());

        return "redirect:/applications/" + applicationId + "/messages";
    }
}
