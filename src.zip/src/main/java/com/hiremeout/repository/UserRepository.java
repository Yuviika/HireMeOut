package com.hiremeout.repository;

import com.hiremeout.domain.PortalUser;
import com.hiremeout.domain.Role;
import java.util.List;
import java.util.Optional;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import java.sql.PreparedStatement;
import java.sql.Statement;

/**
 * Reads and writes rows of the users table, turning them into the right
 * PortalUser subclass (Seeker, Employer or Admin) using PortalUser.fromRow.
 */
@Repository
public class UserRepository {

    private static final RowMapper<PortalUser> USER_MAPPER = (rs, rowNum) -> PortalUser.fromRow(
            rs.getLong("id"),
            rs.getString("name"),
            rs.getString("email"),
            Role.valueOf(rs.getString("role")),
            rs.getString("headline"),
            rs.getString("company_name"));

    private final JdbcTemplate jdbcTemplate;

    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /** Finds one user by id, or empty if no such user exists. */
    public Optional<PortalUser> findById(Long id) {
        List<PortalUser> found = jdbcTemplate.query(
                "SELECT id, name, email, role, headline, company_name FROM users WHERE id = ?",
                USER_MAPPER,
                id);
        return found.stream().findFirst();
    }

    /** Finds one user by email (used for OAuth login lookups), or empty if none exists. */
    public Optional<PortalUser> findByEmail(String email) {
        try {
            PortalUser user = jdbcTemplate.queryForObject(
                    "SELECT id, name, email, role, headline, company_name FROM users WHERE email = ?",
                    USER_MAPPER,
                    email);
            return Optional.ofNullable(user);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    /**
     * Creates a new user row and returns the full PortalUser, including the new id.
     * Only one of headline/companyName is normally set, depending on the role.
     */
    public PortalUser create(String name, String email, Role role, String headline, String companyName) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO users (name, email, role, headline, company_name) VALUES (?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, role.name());
            statement.setString(4, headline);
            statement.setString(5, companyName);
            return statement;
        }, keyHolder);

        Long newId = keyHolder.getKey().longValue();
        return PortalUser.fromRow(newId, name, email, role, headline, companyName);
    }

    /**
     * Finds the first user that has the given role.
     * Used by demo login to pick the demo user for each role (Aarav=seeker,
     * Maya=employer, Riya=admin) without hard-coding any user id.
     */
    public Optional<PortalUser> findOneByRole(Role role) {
        List<PortalUser> found = jdbcTemplate.query(
                "SELECT id, name, email, role, headline, company_name FROM users WHERE role = ? LIMIT 1",
                USER_MAPPER,
                role.name());
        return found.stream().findFirst();
    }
}

