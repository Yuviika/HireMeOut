package com.hiremeout.repository;

import com.hiremeout.domain.Application;
import com.hiremeout.domain.ApplicationStatus;
import com.hiremeout.domain.ApplicationView;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

/** Reads and writes rows of the applications table, plus joined dashboard views. */
@Repository
public class ApplicationRepository {

    private static final RowMapper<Application> APPLICATION_MAPPER = (rs, rowNum) -> new Application(
            rs.getLong("id"),
            rs.getLong("job_id"),
            rs.getLong("seeker_id"),
            rs.getString("cover_note"),
            rs.getString("resume_url"),
            ApplicationStatus.valueOf(rs.getString("status")),
            rs.getTimestamp("applied_at").toLocalDateTime());

    private static final RowMapper<ApplicationView> VIEW_MAPPER = (rs, rowNum) -> new ApplicationView(
            rs.getLong("id"),
            rs.getLong("job_id"),
            rs.getLong("seeker_id"),
            rs.getString("cover_note"),
            rs.getString("resume_url"),
            ApplicationStatus.valueOf(rs.getString("status")),
            rs.getTimestamp("applied_at").toLocalDateTime(),
            rs.getString("job_title"),
            rs.getString("company"),
            rs.getString("seeker_name"));

    private static final String VIEW_SELECT =
            "SELECT a.id, a.job_id, a.seeker_id, a.cover_note, a.resume_url, a.status, a.applied_at, "
                    + "j.title AS job_title, j.company AS company, u.name AS seeker_name "
                    + "FROM applications a "
                    + "JOIN jobs j ON j.id = a.job_id "
                    + "JOIN users u ON u.id = a.seeker_id ";

    private final JdbcTemplate jdbcTemplate;

    public ApplicationRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /** Inserts a new application as APPLIED and returns its generated id. */
    public Long create(Long jobId, Long seekerId, String coverNote, String resumeUrl) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO applications (job_id, seeker_id, cover_note, resume_url, status) "
                            + "VALUES (?, ?, ?, ?, 'APPLIED')",
                    Statement.RETURN_GENERATED_KEYS);
            statement.setLong(1, jobId);
            statement.setLong(2, seekerId);
            statement.setString(3, coverNote);
            statement.setString(4, resumeUrl);
            return statement;
        }, keyHolder);
        return keyHolder.getKey().longValue();
    }

    /** True if this seeker has already applied to this job (the table also has a DB-level UNIQUE constraint). */
    public boolean existsByJobAndSeeker(Long jobId, Long seekerId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM applications WHERE job_id = ? AND seeker_id = ?",
                Integer.class,
                jobId,
                seekerId);
        return count != null && count > 0;
    }

    /** All applications a seeker has sent, with job and company details, newest first. */
    public List<ApplicationView> findViewsBySeeker(Long seekerId) {
        return jdbcTemplate.query(
                VIEW_SELECT + "WHERE a.seeker_id = ? ORDER BY a.applied_at DESC",
                VIEW_MAPPER,
                seekerId);
    }

    /** All applications sent to any job posted by this employer, with seeker details, newest first. */
    public List<ApplicationView> findViewsByEmployer(Long employerId) {
        return jdbcTemplate.query(
                VIEW_SELECT + "WHERE j.employer_id = ? ORDER BY a.applied_at DESC",
                VIEW_MAPPER,
                employerId);
    }

    /** Finds one application by id, or empty if no such application exists. */
    public Optional<Application> findById(Long id) {
        try {
            Application application = jdbcTemplate.queryForObject(
                    "SELECT id, job_id, seeker_id, cover_note, resume_url, status, applied_at FROM applications WHERE id = ?",
                    APPLICATION_MAPPER,
                    id);
            return Optional.ofNullable(application);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    /** Changes an application's status, e.g. when an employer moves a candidate forward. */
    public void updateStatus(Long id, ApplicationStatus status) {
        jdbcTemplate.update("UPDATE applications SET status = ? WHERE id = ?", status.name(), id);
    }
}
