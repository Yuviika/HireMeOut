package com.hiremeout.repository;

import com.hiremeout.domain.Message;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

/** Reads and writes rows of the messages table, the chat thread attached to an application. */
@Repository
public class MessageRepository {

    private static final RowMapper<Message> MESSAGE_MAPPER = (rs, rowNum) -> new Message(
            rs.getLong("id"),
            rs.getLong("application_id"),
            rs.getLong("sender_id"),
            rs.getString("body"),
            rs.getTimestamp("sent_at").toLocalDateTime());

    private final JdbcTemplate jdbcTemplate;

    public MessageRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /** Inserts a new chat message and returns its generated id. */
    public Long create(Long applicationId, Long senderId, String body) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO messages (application_id, sender_id, body) VALUES (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            statement.setLong(1, applicationId);
            statement.setLong(2, senderId);
            statement.setString(3, body);
            return statement;
        }, keyHolder);
        return keyHolder.getKey().longValue();
    }

    /** All messages for one application, oldest first, so a thread reads top to bottom. */
    public List<Message> findByApplication(Long applicationId) {
        return jdbcTemplate.query(
                "SELECT id, application_id, sender_id, body, sent_at FROM messages WHERE application_id = ? ORDER BY sent_at ASC",
                MESSAGE_MAPPER,
                applicationId);
    }
}
