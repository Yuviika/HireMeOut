package com.hiremeout.repository;

import com.hiremeout.domain.Job;
import com.hiremeout.domain.JobStatus;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

/** Reads and writes rows of the jobs table, mapped into the Job record. */
@Repository
public class JobRepository {

    private static final RowMapper<Job> JOB_MAPPER = (rs, rowNum) -> new Job(
            rs.getLong("id"),
            rs.getLong("employer_id"),
            rs.getString("title"),
            rs.getString("company"),
            rs.getString("location"),
            rs.getString("job_type"),
            rs.getString("description"),
            JobStatus.valueOf(rs.getString("status")),
            rs.getTimestamp("created_at").toLocalDateTime());

    private static final String SELECT_COLUMNS =
            "SELECT id, employer_id, title, company, location, job_type, description, status, created_at FROM jobs";

    private final JdbcTemplate jdbcTemplate;

    public JobRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /** Jobs visible on the public job board: APPROVED only, optionally filtered by a title/company search. */
    public List<Job> findApproved(String search) {
        if (search == null || search.isBlank()) {
            return jdbcTemplate.query(
                    SELECT_COLUMNS + " WHERE status = 'APPROVED' ORDER BY created_at DESC",
                    JOB_MAPPER);
        }
        String pattern = "%" + search.trim() + "%";
        return jdbcTemplate.query(
                SELECT_COLUMNS + " WHERE status = 'APPROVED' AND (title LIKE ? OR company LIKE ?) ORDER BY created_at DESC",
                JOB_MAPPER,
                pattern,
                pattern);
    }

    /** Every job regardless of status, newest first. Used by the admin dashboard. */
    public List<Job> findAll() {
        return jdbcTemplate.query(SELECT_COLUMNS + " ORDER BY created_at DESC", JOB_MAPPER);
    }

    /** Finds one job by id, or empty if no such job exists. */
    public Optional<Job> findById(Long id) {
        try {
            Job job = jdbcTemplate.queryForObject(SELECT_COLUMNS + " WHERE id = ?", JOB_MAPPER, id);
            return Optional.ofNullable(job);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    /** Jobs posted by one employer, newest first. Used by the employer dashboard. */
    public List<Job> findByEmployer(Long employerId) {
        return jdbcTemplate.query(
                SELECT_COLUMNS + " WHERE employer_id = ? ORDER BY created_at DESC",
                JOB_MAPPER,
                employerId);
    }

    /** Inserts a new job as PENDING and returns its generated id. */
    public Long create(Long employerId, String title, String company, String location, String jobType, String description) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO jobs (employer_id, title, company, location, job_type, description, status) "
                            + "VALUES (?, ?, ?, ?, ?, ?, 'PENDING')",
                    Statement.RETURN_GENERATED_KEYS);
            statement.setLong(1, employerId);
            statement.setString(2, title);
            statement.setString(3, company);
            statement.setString(4, location);
            statement.setString(5, jobType);
            statement.setString(6, description);
            return statement;
        }, keyHolder);
        return keyHolder.getKey().longValue();
    }

    /** Changes a job's status, e.g. when an admin approves or rejects it. */
    public void updateStatus(Long id, JobStatus status) {
        jdbcTemplate.update("UPDATE jobs SET status = ? WHERE id = ?", status.name(), id);
    }
}
