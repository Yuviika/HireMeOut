package com.hiremeout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HireMeOutApplication {
    public static void main(String[] args) {
        SpringApplication.run(HireMeOutApplication.class, args);
    }
}
