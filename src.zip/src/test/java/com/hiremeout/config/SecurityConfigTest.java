package com.hiremeout.config;

import com.hiremeout.controller.DemoLoginController;
import com.hiremeout.controller.OAuthErrorController;
import com.hiremeout.domain.Role;
import com.hiremeout.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.oauth2.client.servlet.OAuth2ClientAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Security integration tests for Part 4.
 *
 * <p>These tests verify the HTTP access rules without needing a running MySQL database.
 *
 * <p>Design decisions:
 * <ul>
 *   <li>{@code @WebMvcTest(controllers = ...)} loads only the two controllers under test,
 *       keeping the context small and avoiding any need for a database.
 *   <li>{@code OAuth2ClientAutoConfiguration} is excluded because no OAuth provider is
 *       configured in the test environment and its presence can cause bean wiring errors.
 *   <li>{@code @MockBean UserRepository} is the only repository needed; it replaces the
 *       real one without requiring a database connection.
 * </ul>
 *
 * <p>Beginners: {@code @WebMvcTest} is like running a tiny slice of the application —
 * just the HTTP layer (controllers + security) — so tests are fast and isolated.
 */
@WebMvcTest(
        controllers = {DemoLoginController.class, OAuthErrorController.class},
        excludeAutoConfiguration = OAuth2ClientAutoConfiguration.class
)
@Import(SecurityConfig.class)
@TestPropertySource(properties = {
        "spring.security.oauth2.client.registration.google.client-id=",
        "spring.security.oauth2.client.registration.github.client-id=",
        "app.allowed-origins=http://localhost:8080"
})
class SecurityConfigTest {

    @Autowired
    private MockMvc mockMvc;

    /**
     * {@code UserRepository} is the only dependency of the controllers under test.
     * {@code @MockBean} replaces it with a do-nothing stub — no database needed.
     */
    @MockBean
    private UserRepository userRepository;

    // ── Test a: Anonymous user is blocked from the admin dashboard ────────────

    /**
     * An unauthenticated request to the admin dashboard must NOT succeed.
     * Spring Security redirects anonymous users (302) to the home page with
     * "?signin" so the page can explain why, instead of serving the dashboard.
     */
    @Test
    void anonymousUserIsBlockedFromAdminDashboard() throws Exception {
        mockMvc.perform(get("/dashboard/admin"))
                .andExpect(status().is3xxRedirection())
                .andExpect(result -> {
                    String location = result.getResponse().getRedirectedUrl();
                    if (location == null || !location.endsWith("/?signin")) {
                        throw new AssertionError("Expected a redirect to /?signin but got " + location);
                    }
                });
    }

    /** The old prototype URLs (/demo/admin) are protected too: anonymous visitors are redirected. */
    @Test
    void anonymousUserIsBlockedFromLegacyDemoLink() throws Exception {
        mockMvc.perform(get("/demo/admin"))
                .andExpect(status().is3xxRedirection());
    }

    /** A signed-in SEEKER typing the admin dashboard URL must receive 403 Forbidden. */
    @Test
    void seekerIsForbiddenOnAdminDashboard() throws Exception {
        AppUser seekerPrincipal = new AppUser(1L, "Aarav", Role.SEEKER);

        mockMvc.perform(get("/dashboard/admin").with(user(seekerPrincipal)))
                .andExpect(status().isForbidden());
    }

    /** Only seekers may apply: a signed-in EMPLOYER posting to the apply route gets 403. */
    @Test
    void employerIsForbiddenOnApplyRoute() throws Exception {
        AppUser employerPrincipal = new AppUser(2L, "Maya", Role.EMPLOYER);

        mockMvc.perform(
                post("/jobs/1/apply")
                        .param("coverNote", "Hello")
                        .with(csrf())
                        .with(user(employerPrincipal))
        ).andExpect(status().isForbidden());
    }

    // ── Test b: SEEKER role gets 403 on the admin job-review route ────────────

    /**
     * A logged-in SEEKER must receive 403 Forbidden when reaching the
     * admin-only job review endpoint. This proves role-based access is enforced.
     */
    @Test
    void seekerIsForbiddenOnAdminJobReview() throws Exception {
        AppUser seekerPrincipal = new AppUser(1L, "Aarav", Role.SEEKER);

        mockMvc.perform(
                post("/jobs/42/review")
                        .param("decision", "APPROVED")
                        .with(csrf())
                        .with(user(seekerPrincipal))
        ).andExpect(status().isForbidden());
    }

    // ── Test c: POST without CSRF token is rejected ────────────────────────────

    /**
     * A POST that omits the CSRF token must be rejected with 403 Forbidden.
     * This proves CSRF protection is active — it was disabled in the old config.
     */
    @Test
    void postWithoutCsrfTokenIsRejected() throws Exception {
        mockMvc.perform(
                post("/demo-login/seeker")
                // Deliberately NOT calling .with(csrf()) to prove CSRF is enforced.
        ).andExpect(status().isForbidden());
    }

    // ── Test d: POST with a valid CSRF token passes security ──────────────────

    /**
     * A POST with a valid CSRF token to a public endpoint must NOT be blocked
     * by the security layer (the response may be anything the controller returns,
     * but it must not be 401 or 403).
     *
     * <p>We test /demo-login/seeker: it is public, so security should pass it
     * through. The controller will look up the user (UserRepository returns empty
     * from the mock) and render the demo-error template (200 OK).
     */
    @Test
    void postWithCsrfTokenIsNotBlockedBySecurity() throws Exception {
        mockMvc.perform(
                post("/demo-login/seeker")
                        .with(csrf())
        ).andExpect(result -> {
            int status = result.getResponse().getStatus();
            if (status == 401 || status == 403) {
                throw new AssertionError(
                        "Expected security to allow POST /demo-login/seeker with CSRF, but got " + status);
            }
        });
    }
}
