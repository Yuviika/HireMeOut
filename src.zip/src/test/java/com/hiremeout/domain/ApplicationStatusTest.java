package com.hiremeout.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.hiremeout.domain.exception.ValidationException;
import java.util.List;
import org.junit.jupiter.api.Test;

class ApplicationStatusTest {

    @Test
    void forwardMovesAreAllowed() {
        assertTrue(ApplicationStatus.APPLIED.canMoveTo(ApplicationStatus.REVIEWING));
        assertTrue(ApplicationStatus.REVIEWING.canMoveTo(ApplicationStatus.INTERVIEW));
        assertTrue(ApplicationStatus.INTERVIEW.canMoveTo(ApplicationStatus.OFFER));
    }

    @Test
    void anyActiveStageCanBeRejected() {
        assertTrue(ApplicationStatus.APPLIED.canMoveTo(ApplicationStatus.REJECTED));
        assertTrue(ApplicationStatus.REVIEWING.canMoveTo(ApplicationStatus.REJECTED));
        assertTrue(ApplicationStatus.INTERVIEW.canMoveTo(ApplicationStatus.REJECTED));
    }

    @Test
    void skippingOrGoingBackwardsIsNotAllowed() {
        assertFalse(ApplicationStatus.APPLIED.canMoveTo(ApplicationStatus.OFFER));
        assertFalse(ApplicationStatus.REVIEWING.canMoveTo(ApplicationStatus.APPLIED));
        assertFalse(ApplicationStatus.INTERVIEW.canMoveTo(ApplicationStatus.REVIEWING));
    }

    @Test
    void offerAndRejectedAreTerminal() {
        assertTrue(ApplicationStatus.OFFER.isTerminal());
        assertTrue(ApplicationStatus.REJECTED.isTerminal());
        assertFalse(ApplicationStatus.APPLIED.isTerminal());
    }

    @Test
    void nextOptionsListsOnlyAllowedStatuses() {
        assertEquals(
                List.of(ApplicationStatus.INTERVIEW, ApplicationStatus.REJECTED),
                ApplicationStatus.REVIEWING.nextOptions());
    }

    @Test
    void everyStatusHasALabel() {
        for (ApplicationStatus status : ApplicationStatus.values()) {
            assertFalse(status.label().isBlank());
        }
    }

    @Test
    void fromStringAcceptsDifferentCaseAndSpaces() {
        assertEquals(ApplicationStatus.INTERVIEW, ApplicationStatus.fromString("  interview "));
    }

    @Test
    void fromStringRejectsBadInput() {
        assertThrows(ValidationException.class, () -> ApplicationStatus.fromString("HIRED"));
        assertThrows(ValidationException.class, () -> ApplicationStatus.fromString(""));
        assertThrows(ValidationException.class, () -> ApplicationStatus.fromString(null));
    }

    @Test
    void jobStatusDecisionsAndParsing() {
        assertTrue(JobStatus.APPROVED.isDecision());
        assertTrue(JobStatus.REJECTED.isDecision());
        assertFalse(JobStatus.PENDING.isDecision());
        assertEquals(JobStatus.APPROVED, JobStatus.fromString("approved"));
        assertThrows(ValidationException.class, () -> JobStatus.fromString("MAYBE"));
    }
}
