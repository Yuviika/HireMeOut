package com.hiremeout.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.hiremeout.domain.exception.ConflictException;
import com.hiremeout.domain.exception.ForbiddenException;
import com.hiremeout.domain.exception.NotFoundException;
import com.hiremeout.domain.exception.PortalException;
import com.hiremeout.domain.exception.ValidationException;
import java.util.List;
import org.junit.jupiter.api.Test;

class PortalUserTest {

    @Test
    void fromRowBuildsTheRightSubclass() {
        PortalUser seeker = PortalUser.fromRow(1L, "Aarav", "a@x.io", Role.SEEKER, "Java dev", null);
        PortalUser employer = PortalUser.fromRow(2L, "Maya", "m@x.io", Role.EMPLOYER, null, "Studio North");
        PortalUser admin = PortalUser.fromRow(3L, "Riya", "r@x.io", Role.ADMIN, null, null);

        assertInstanceOf(Seeker.class, seeker);
        assertInstanceOf(Employer.class, employer);
        assertInstanceOf(Admin.class, admin);
        assertEquals("Studio North", ((Employer) employer).company());
        assertEquals("Java dev", ((Seeker) seeker).headline());
    }

    @Test
    void fromRowRejectsMissingRole() {
        assertThrows(IllegalArgumentException.class,
                () -> PortalUser.fromRow(1L, "A", "a@x.io", null, null, null));
    }

    @Test
    void eachRoleHasItsOwnDashboardText() {
        PortalUser seeker = PortalUser.fromRow(1L, "Aarav", "a@x.io", Role.SEEKER, null, null);
        PortalUser admin = PortalUser.fromRow(3L, "Riya", "r@x.io", Role.ADMIN, null, null);

        assertEquals("Seeker space", seeker.dashboardTitle());
        assertEquals("Admin space", admin.dashboardTitle());
        assertEquals("Your next role is out there, Aarav.", seeker.welcomeLine());
        assertEquals(Role.ADMIN, admin.role());
    }

    @Test
    void exceptionsCarryTheRightHttpStatus() {
        assertEquals(404, new NotFoundException("x").getStatus());
        assertEquals(400, new ValidationException("x").getStatus());
        assertEquals(403, new ForbiddenException("x").getStatus());
        assertEquals(409, new ConflictException("x").getStatus());
        assertEquals("nope", new PortalException("nope", 500).getUserMessage());
    }

    @Test
    void snapshotHoldsTypedItemsAndIsImmutable() {
        PortalUser seeker = PortalUser.fromRow(1L, "Aarav", "a@x.io", Role.SEEKER, null, null);
        DashboardSnapshot<String> snapshot = DashboardSnapshot.of(seeker, List.of("one", "two"), "Hi");

        assertEquals(2, snapshot.items().size());
        assertEquals("Hi", snapshot.headline());
        assertThrows(UnsupportedOperationException.class, () -> snapshot.items().add("three"));
    }
}
