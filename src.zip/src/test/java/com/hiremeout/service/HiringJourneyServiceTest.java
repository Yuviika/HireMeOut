package com.hiremeout.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.hiremeout.domain.Admin;
import com.hiremeout.domain.Application;
import com.hiremeout.domain.ApplicationStatus;
import com.hiremeout.domain.ApplicationView;
import com.hiremeout.domain.Employer;
import com.hiremeout.domain.Job;
import com.hiremeout.domain.JobStatus;
import com.hiremeout.domain.Message;
import com.hiremeout.domain.PortalUser;
import com.hiremeout.domain.Seeker;
import com.hiremeout.domain.exception.ConflictException;
import com.hiremeout.domain.exception.ForbiddenException;
import com.hiremeout.domain.exception.ValidationException;
import com.hiremeout.repository.ApplicationRepository;
import com.hiremeout.repository.JobRepository;
import com.hiremeout.repository.MessageRepository;
import com.hiremeout.repository.UserRepository;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Walks through the whole hiring journey at the service level:
 * employer posts a job, admin approves it, seeker applies, employer moves the
 * candidate through the stages, and both sides exchange messages.
 *
 * <p>Beginner note: these tests need NO database and NO Spring. The services
 * only talk to repositories, so we hand them tiny in-memory "fake" repositories
 * (defined at the bottom of this file) instead of the real MySQL-backed ones.
 * That makes the tests fast and lets them check the business rules on their own.
 */
class HiringJourneyServiceTest {

    private static final Long SEEKER_ID = 1L;
    private static final Long EMPLOYER_ID = 2L;
    private static final Long ADMIN_ID = 3L;
    private static final Long OTHER_EMPLOYER_ID = 4L;
    private static final Long OTHER_SEEKER_ID = 5L;

    private FakeUsers users;
    private FakeJobs jobs;
    private FakeApplications applications;
    private FakeMessages messages;
    private RecordingPublisher publisher;

    private JobService jobService;
    private ApplicationService applicationService;
    private DashboardService dashboardService;
    private MessageService messageService;

    @BeforeEach
    void setUp() {
        users = new FakeUsers();
        jobs = new FakeJobs();
        applications = new FakeApplications(jobs, users);
        messages = new FakeMessages();
        publisher = new RecordingPublisher();

        users.add(new Seeker(SEEKER_ID, "Aarav", "aarav@example.com", "Java developer"));
        users.add(new Employer(EMPLOYER_ID, "Maya", "maya@example.com", "Studio North"));
        users.add(new Admin(ADMIN_ID, "Riya", "riya@example.com"));
        users.add(new Employer(OTHER_EMPLOYER_ID, "Omar", "omar@example.com", "Other Co"));
        users.add(new Seeker(OTHER_SEEKER_ID, "Sana", "sana@example.com", "Designer"));

        jobService = new JobService(jobs, users, publisher);
        applicationService = new ApplicationService(applications, jobs, publisher);
        dashboardService = new DashboardService(users, jobs, applications);
        messageService = new MessageService(messages, applications, jobs);
    }

    @Test
    void fullHiringJourneyWorksEndToEnd() {
        // 1. The employer posts a job. It starts PENDING and uses the employer's own company name.
        Job posted = jobService.postJob(EMPLOYER_ID, "Backend Engineer", "Remote", "Full-time", "Build APIs.");
        assertEquals(JobStatus.PENDING, posted.status());
        assertEquals("Studio North", posted.company());
        assertTrue(jobService.listApproved("").isEmpty(), "pending jobs must not be on the public board");

        // 2. The admin approves it, so it appears on the job board (and search finds it).
        jobService.review(ADMIN_ID, posted.id(), JobStatus.APPROVED);
        assertEquals(1, jobService.listApproved("").size());
        assertEquals(1, jobService.listApproved("backend").size());
        assertTrue(jobService.listApproved("designer").isEmpty());

        // 3. The seeker applies. Applying twice is refused.
        Application application = applicationService.apply(SEEKER_ID, posted.id(), "I would love this role.", "");
        assertEquals(ApplicationStatus.APPLIED, application.status());
        assertThrows(ConflictException.class,
                () -> applicationService.apply(SEEKER_ID, posted.id(), "Again", ""));

        // 4. The employer walks the candidate through the stages, one legal step at a time.
        applicationService.changeStatus(EMPLOYER_ID, application.id(), ApplicationStatus.REVIEWING);
        applicationService.changeStatus(EMPLOYER_ID, application.id(), ApplicationStatus.INTERVIEW);
        applicationService.changeStatus(EMPLOYER_ID, application.id(), ApplicationStatus.OFFER);

        // An offer is final: nothing can follow it.
        assertThrows(ValidationException.class,
                () -> applicationService.changeStatus(EMPLOYER_ID, application.id(), ApplicationStatus.REJECTED));

        // 5. Each role's dashboard shows the right data.
        List<ApplicationView> seekerItems = dashboardService.seekerDashboard(SEEKER_ID).items();
        assertEquals(1, seekerItems.size());
        assertEquals(ApplicationStatus.OFFER, seekerItems.get(0).status());
        assertEquals("Backend Engineer", seekerItems.get(0).jobTitle());

        List<ApplicationView> employerItems = dashboardService.employerDashboard(EMPLOYER_ID).items();
        assertEquals(1, employerItems.size());
        assertEquals("Aarav", employerItems.get(0).seekerName());

        assertEquals(1, dashboardService.adminDashboard(ADMIN_ID).items().size());
        assertEquals("0 job(s) waiting for review.", dashboardService.adminDashboard(ADMIN_ID).headline());

        // 6. Seeker and employer can talk; the admin is not part of this conversation.
        messageService.send(EMPLOYER_ID, application.id(), "Congratulations, we would like to make you an offer!");
        messageService.send(SEEKER_ID, application.id(), "Thank you, that is wonderful news.");
        List<Message> thread = messageService.list(application.id(), SEEKER_ID);
        assertEquals(2, thread.size());
        assertEquals(EMPLOYER_ID, thread.get(0).senderId());
        assertThrows(ForbiddenException.class, () -> messageService.list(application.id(), ADMIN_ID));

        // 7. Live events were published for every successful step, and for nothing that failed.
        assertEquals(
                List.of(
                        "JOB_POSTED",
                        "JOB_REVIEWED",
                        "APPLICATION_RECEIVED",
                        "APPLICATION_STATUS_CHANGED",
                        "APPLICATION_STATUS_CHANGED",
                        "APPLICATION_STATUS_CHANGED"),
                publisher.types);
    }

    @Test
    void jobThatIsStillPendingCannotReceiveApplications() {
        Job posted = jobService.postJob(EMPLOYER_ID, "QA Engineer", "Remote", "Full-time", "Test things.");

        assertThrows(ValidationException.class,
                () -> applicationService.apply(SEEKER_ID, posted.id(), "Please?", ""));
        assertTrue(publisher.types.stream().noneMatch(type -> type.equals("APPLICATION_RECEIVED")));
    }

    @Test
    void rejectedJobCannotBeReviewedAgain() {
        Job posted = jobService.postJob(EMPLOYER_ID, "Designer", "Remote", "Internship", "Design things.");
        jobService.review(ADMIN_ID, posted.id(), JobStatus.REJECTED);

        assertThrows(ConflictException.class,
                () -> jobService.review(ADMIN_ID, posted.id(), JobStatus.APPROVED));
    }

    @Test
    void employerCannotManageAnotherEmployersApplications() {
        Job posted = approvedJob();
        Application application = applicationService.apply(SEEKER_ID, posted.id(), "Hi", "");

        assertThrows(ForbiddenException.class,
                () -> applicationService.changeStatus(OTHER_EMPLOYER_ID, application.id(), ApplicationStatus.REVIEWING));
    }

    @Test
    void seekersOnlySeeTheirOwnApplications() {
        Job posted = approvedJob();
        applicationService.apply(SEEKER_ID, posted.id(), "From Aarav", "");
        applicationService.apply(OTHER_SEEKER_ID, posted.id(), "From Sana", "");

        List<ApplicationView> aaravsView = dashboardService.seekerDashboard(SEEKER_ID).items();
        assertEquals(1, aaravsView.size());
        assertEquals("From Aarav", aaravsView.get(0).coverNote());

        // The employer, on the other hand, sees both candidates for their job.
        assertEquals(2, dashboardService.employerDashboard(EMPLOYER_ID).items().size());
        // And a different employer sees none of them.
        assertTrue(dashboardService.employerDashboard(OTHER_EMPLOYER_ID).items().isEmpty());
    }

    @Test
    void invalidJobFormsAreRejectedBeforeAnythingIsSaved() {
        assertThrows(ValidationException.class,
                () -> jobService.postJob(EMPLOYER_ID, "  ", "Remote", "Full-time", "Description"));
        assertThrows(ValidationException.class,
                () -> jobService.postJob(EMPLOYER_ID, "Title", "Remote", "Full-time", ""));
        assertFalse(jobs.findAll().iterator().hasNext(), "nothing should have been saved");
    }

    private Job approvedJob() {
        Job posted = jobService.postJob(EMPLOYER_ID, "Backend Engineer", "Remote", "Full-time", "Build APIs.");
        jobService.review(ADMIN_ID, posted.id(), JobStatus.APPROVED);
        return posted;
    }

    // ------------------------------------------------------------------------
    // In-memory fakes. Each one extends the real repository class (passing null
    // for the unused JdbcTemplate) and overrides only the methods the services call.
    // ------------------------------------------------------------------------

    /** Remembers the type of every live event that would have been sent to browsers. */
    private static class RecordingPublisher extends LiveEventPublisher {
        final List<String> types = new ArrayList<>();

        RecordingPublisher() {
            super(null);
        }

        @Override
        public void publish(String type, String message) {
            types.add(type);
        }
    }

    private static class FakeUsers extends UserRepository {
        private final Map<Long, PortalUser> byId = new HashMap<>();

        FakeUsers() {
            super(null);
        }

        void add(PortalUser user) {
            byId.put(user.id(), user);
        }

        @Override
        public Optional<PortalUser> findById(Long id) {
            return Optional.ofNullable(byId.get(id));
        }
    }

    private static class FakeJobs extends JobRepository {
        private final Map<Long, Job> byId = new HashMap<>();
        private long nextId = 1;

        FakeJobs() {
            super(null);
        }

        @Override
        public Long create(Long employerId, String title, String company, String location, String jobType, String description) {
            Long id = nextId++;
            byId.put(id, new Job(id, employerId, title, company, location, jobType, description,
                    JobStatus.PENDING, LocalDateTime.now()));
            return id;
        }

        @Override
        public Optional<Job> findById(Long id) {
            return Optional.ofNullable(byId.get(id));
        }

        @Override
        public List<Job> findAll() {
            return new ArrayList<>(byId.values());
        }

        @Override
        public List<Job> findByEmployer(Long employerId) {
            return byId.values().stream().filter(job -> job.employerId().equals(employerId)).toList();
        }

        @Override
        public List<Job> findApproved(String search) {
            String term = (search == null) ? "" : search.trim().toLowerCase(Locale.ROOT);
            return byId.values().stream()
                    .filter(job -> job.status() == JobStatus.APPROVED)
                    .filter(job -> term.isEmpty()
                            || job.title().toLowerCase(Locale.ROOT).contains(term)
                            || job.company().toLowerCase(Locale.ROOT).contains(term))
                    .toList();
        }

        @Override
        public void updateStatus(Long id, JobStatus status) {
            Job job = byId.get(id);
            byId.put(id, new Job(job.id(), job.employerId(), job.title(), job.company(), job.location(),
                    job.jobType(), job.description(), status, job.createdAt()));
        }
    }

    private static class FakeApplications extends ApplicationRepository {
        private final Map<Long, Application> byId = new HashMap<>();
        private final FakeJobs jobs;
        private final FakeUsers users;
        private long nextId = 1;

        FakeApplications(FakeJobs jobs, FakeUsers users) {
            super(null);
            this.jobs = jobs;
            this.users = users;
        }

        @Override
        public Long create(Long jobId, Long seekerId, String coverNote, String resumeUrl) {
            Long id = nextId++;
            byId.put(id, new Application(id, jobId, seekerId, coverNote, resumeUrl,
                    ApplicationStatus.APPLIED, LocalDateTime.now()));
            return id;
        }

        @Override
        public boolean existsByJobAndSeeker(Long jobId, Long seekerId) {
            return byId.values().stream()
                    .anyMatch(a -> a.jobId().equals(jobId) && a.seekerId().equals(seekerId));
        }

        @Override
        public Optional<Application> findById(Long id) {
            return Optional.ofNullable(byId.get(id));
        }

        @Override
        public void updateStatus(Long id, ApplicationStatus status) {
            Application a = byId.get(id);
            byId.put(id, new Application(a.id(), a.jobId(), a.seekerId(), a.coverNote(), a.resumeUrl(),
                    status, a.appliedAt()));
        }

        @Override
        public List<ApplicationView> findViewsBySeeker(Long seekerId) {
            return byId.values().stream().filter(a -> a.seekerId().equals(seekerId)).map(this::toView).toList();
        }

        @Override
        public List<ApplicationView> findViewsByEmployer(Long employerId) {
            return byId.values().stream()
                    .filter(a -> jobs.findById(a.jobId()).orElseThrow().employerId().equals(employerId))
                    .map(this::toView)
                    .toList();
        }

        private ApplicationView toView(Application a) {
            Job job = jobs.findById(a.jobId()).orElseThrow();
            PortalUser seeker = users.findById(a.seekerId()).orElseThrow();
            return new ApplicationView(a.id(), a.jobId(), a.seekerId(), a.coverNote(), a.resumeUrl(),
                    a.status(), a.appliedAt(), job.title(), job.company(), seeker.name());
        }
    }

    private static class FakeMessages extends MessageRepository {
        private final List<Message> all = new ArrayList<>();
        private long nextId = 1;

        FakeMessages() {
            super(null);
        }

        @Override
        public Long create(Long applicationId, Long senderId, String body) {
            Long id = nextId++;
            all.add(new Message(id, applicationId, senderId, body, LocalDateTime.now()));
            return id;
        }

        @Override
        public List<Message> findByApplication(Long applicationId) {
            return all.stream().filter(m -> m.applicationId().equals(applicationId)).toList();
        }
    }
}
